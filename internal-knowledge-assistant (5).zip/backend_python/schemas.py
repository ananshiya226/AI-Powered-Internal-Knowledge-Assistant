from typing import List, Optional, Literal
from pydantic import BaseModel, Field

SourceCategory = Literal['engineering', 'hr_people', 'slack_threads', 'security_it', 'product_wiki', 'glossary']

class DocumentMetadata(BaseModel):
    id: str
    title: str
    category: SourceCategory
    source_type: str = Field(alias="sourceType")
    author: str
    last_updated: str = Field(alias="lastUpdated")
    channel_or_url: Optional[str] = Field(default=None, alias="channelOrUrl")
    tags: List[str] = []
    department: str

    class Config:
        populate_by_name = True

class KnowledgeDocument(DocumentMetadata):
    content: str
    chunk_count: Optional[int] = Field(default=0, alias="chunkCount")

class DocumentChunk(BaseModel):
    id: str
    doc_id: str = Field(alias="docId")
    doc_title: str = Field(alias="docTitle")
    category: SourceCategory
    source_type: str = Field(alias="sourceType")
    department: str
    channel_or_url: Optional[str] = Field(default=None, alias="channelOrUrl")
    chunk_index: int = Field(alias="chunkIndex")
    total_chunks: int = Field(alias="totalChunks")
    text: str
    token_count: int = Field(alias="tokenCount")
    embedding: Optional[List[float]] = None

    class Config:
        populate_by_name = True

class SearchResult(BaseModel):
    chunk: DocumentChunk
    score: float
    vector_score: float = Field(alias="vectorScore")
    keyword_score: float = Field(alias="keywordScore")
    matched_keywords: List[str] = Field(alias="matchedKeywords")

    class Config:
        populate_by_name = True

class GroundedCitation(BaseModel):
    chunk_id: str = Field(alias="chunkId")
    doc_id: str = Field(alias="docId")
    doc_title: str = Field(alias="docTitle")
    category: SourceCategory
    source_type: str = Field(alias="sourceType")
    channel_or_url: Optional[str] = Field(default=None, alias="channelOrUrl")
    snippet: str
    score: float

    class Config:
        populate_by_name = True

class RetrievalStats(BaseModel):
    total_chunks_indexed: int = Field(alias="totalChunksIndexed")
    searched_chunks: int = Field(alias="searchedChunks")
    top_matches_count: int = Field(alias="topMatchesCount")
    query_execution_time_ms: float = Field(alias="queryExecutionTimeMs")
    embedding_model: str = Field(alias="embeddingModel")

    class Config:
        populate_by_name = True

class RAGQueryRequest(BaseModel):
    query: str
    category_filter: Optional[str] = Field(default='all', alias="categoryFilter")

    class Config:
        populate_by_name = True

class RAGQueryResponse(BaseModel):
    answer: str
    citations: List[GroundedCitation]
    confidence: Literal['high', 'medium', 'low', 'insufficient_knowledge']
    suggested_follow_ups: List[str] = Field(alias="suggestedFollowUps")
    action_steps: Optional[List[str]] = Field(default=[], alias="actionSteps")
    contact_point: Optional[str] = Field(default=None, alias="contactPoint")
    is_knowledge_gap: bool = Field(alias="isKnowledgeGap")
    retrieval_stats: RetrievalStats = Field(alias="retrievalStats")

    class Config:
        populate_by_name = True
