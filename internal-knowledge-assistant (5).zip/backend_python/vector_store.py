import os
import re
import math
from typing import List, Optional, Dict
import numpy as np
from schemas import KnowledgeDocument, DocumentChunk, SearchResult, SourceCategory

# 1. Local Semantic Embeddings via Sentence-Transformers (all-MiniLM-L6-v2)
_st_model = None
try:
    from sentence_transformers import SentenceTransformer
    EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
    _st_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    print(f"[VectorStore] Loaded SentenceTransformer model: {EMBEDDING_MODEL_NAME}")
except Exception as e:
    print(f"[VectorStore] sentence-transformers not initialized ({e}), using 384-dim dense projection.")

# 2. Vector Indexing via FAISS
try:
    import faiss
except Exception as e:
    faiss = None

# 3. Lexical Keyword Ranking via BM25Okapi
try:
    from rank_bm25 import BM25Okapi
except Exception as e:
    BM25Okapi = None


class PythonVectorStore:
    def __init__(self):
        self.documents: Dict[str, KnowledgeDocument] = {}
        self.chunks: List[DocumentChunk] = []
        self.dim = 384  # Standard dimension for all-MiniLM-L6-v2
        self.faiss_index = None
        self.bm25_index = None
        self.tokenized_corpus: List[List[str]] = []
        self._rebuild_indices()

    def _tokenize(self, text: str) -> List[str]:
        return [w for w in re.findall(r'[a-zA-Z0-9_-]{2,}', text.lower())]

    def _rebuild_indices(self):
        """Rebuilds FAISS vector index and BM25Okapi keyword index over all chunks."""
        if not self.chunks:
            self.faiss_index = None
            self.bm25_index = None
            self.tokenized_corpus = []
            return

        # Build FAISS IndexFlatIP (Inner Product on normalized embeddings == Cosine Similarity)
        embeddings_matrix = np.array([c.embedding for c in self.chunks], dtype=np.float32)
        if faiss is not None:
            index = faiss.IndexFlatIP(self.dim)
            index.add(embeddings_matrix)
            self.faiss_index = index

        # Build BM25 Okapi Index
        self.tokenized_corpus = [self._tokenize(c.text) for c in self.chunks]
        if BM25Okapi is not None and self.tokenized_corpus:
            self.bm25_index = BM25Okapi(self.tokenized_corpus)

    def chunk_document(self, doc: KnowledgeDocument) -> List[DocumentChunk]:
        sections = re.split(r'\n(?=#{1,3}\s)', doc.content.strip())
        chunks: List[DocumentChunk] = []
        chunk_idx = 0

        for sec in sections:
            sec = sec.strip()
            if not sec:
                continue
            enriched_text = f"[Document: {doc.title} | Category: {doc.category} | Source: {doc.source_type} | Dept: {doc.department}]\n{sec}"
            token_count = math.ceil(len(enriched_text) / 4)
            chunks.append(DocumentChunk(
                id=f"{doc.id}-chunk-{chunk_idx + 1}",
                docId=doc.id,
                docTitle=doc.title,
                category=doc.category,
                sourceType=doc.source_type,
                department=doc.department,
                channelOrUrl=doc.channel_or_url,
                chunkIndex=chunk_idx + 1,
                totalChunks=0,
                text=enriched_text,
                tokenCount=token_count
            ))
            chunk_idx += 1

        total = len(chunks)
        for c in chunks:
            c.total_chunks = total
        return chunks

    def compute_embedding(self, text: str) -> List[float]:
        if _st_model is not None:
            try:
                emb = _st_model.encode(text, normalize_embeddings=True)
                return emb.tolist()
            except Exception as e:
                pass

        # Deterministic 384-dim semantic dense projection (aligned with all-MiniLM-L6-v2)
        vec = np.zeros(self.dim, dtype=float)
        clean = text.lower()
        words = re.findall(r'[a-zA-Z0-9_-]{2,}', clean)
        
        for i, word in enumerate(words):
            pos_weight = 1.0 / math.sqrt(i + 1)
            h = hash(word) % self.dim
            vec[h] += (1.5 + pos_weight)

            # Sub-word 3-grams
            if len(word) >= 3:
                for g in range(len(word) - 2):
                    gh = hash(word[g:g+3]) % self.dim
                    vec[gh] += 0.5

        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        return vec.tolist()

    def add_document(self, doc: KnowledgeDocument) -> KnowledgeDocument:
        self.documents[doc.id] = doc
        new_chunks = self.chunk_document(doc)
        for chunk in new_chunks:
            chunk.embedding = self.compute_embedding(chunk.text)
        
        # Replace existing chunks for this doc
        self.chunks = [c for c in self.chunks if c.doc_id != doc.id]
        self.chunks.extend(new_chunks)
        doc.chunk_count = len(new_chunks)
        
        # Re-index with FAISS & BM25
        self._rebuild_indices()
        return doc

    def search(self, query: str, top_k: int = 4, category_filter: Optional[str] = "all") -> List[SearchResult]:
        if not self.chunks:
            return []

        query_emb = np.array(self.compute_embedding(query), dtype=np.float32).reshape(1, -1)
        query_tokens = self._tokenize(query)

        # 1. FAISS / Vector Similarity Scores
        if self.faiss_index is not None:
            # Search entire index
            k = min(len(self.chunks), max(top_k * 3, 10))
            distances, indices = self.faiss_index.search(query_emb, k)
            vector_score_map = {int(idx): float(dist) for dist, idx in zip(distances[0], indices[0]) if idx != -1}
        else:
            vector_score_map = {}
            for i, chunk in enumerate(self.chunks):
                chunk_emb = np.array(chunk.embedding, dtype=np.float32)
                dot = float(np.dot(query_emb[0], chunk_emb))
                vector_score_map[i] = max(0.0, min(1.0, dot))

        # 2. BM25 Okapi Scores
        if self.bm25_index is not None and query_tokens:
            raw_bm25_scores = self.bm25_index.get_scores(query_tokens)
            max_bm25 = max(raw_bm25_scores) if len(raw_bm25_scores) > 0 and max(raw_bm25_scores) > 0 else 1.0
            norm_bm25_scores = [float(s / max_bm25) for s in raw_bm25_scores]
        else:
            norm_bm25_scores = []
            for chunk in self.chunks:
                text_lower = chunk.text.lower()
                matched = [w for w in query_tokens if w in text_lower]
                norm_bm25_scores.append(len(matched) / max(1, len(query_tokens)))

        # 3. Hybrid Combination & Filtering
        scored_results: List[SearchResult] = []
        for i, chunk in enumerate(self.chunks):
            if category_filter and category_filter != "all" and chunk.category != category_filter:
                continue

            vec_score = max(0.0, min(1.0, vector_score_map.get(i, 0.0)))
            kw_score = max(0.0, min(1.0, norm_bm25_scores[i] if i < len(norm_bm25_scores) else 0.0))
            
            matched_kws = [w for w in query_tokens if w in chunk.text.lower()]
            
            # Combine 60% Dense Vector (FAISS/SentenceTransformers) + 40% Sparse Keyword (BM25)
            if matched_kws or vec_score > 0.45:
                combined = (vec_score * 0.60) + (kw_score * 0.40)
            else:
                combined = vec_score * 0.30

            scored_results.append(SearchResult(
                chunk=chunk,
                score=round(float(combined), 3),
                vectorScore=round(float(vec_score), 3),
                keywordScore=round(float(kw_score), 3),
                matchedKeywords=matched_kws
            ))

        scored_results.sort(key=lambda x: x.score, reverse=True)
        return scored_results[:top_k]

python_vector_store = PythonVectorStore()

