import os
import re
import time
from typing import Optional, List
import httpx
from schemas import RAGQueryResponse, GroundedCitation, RetrievalStats, SearchResult
from vector_store import python_vector_store, _st_model

# Local Ollama Configuration (defaults to localhost:11434 with llama3.2 / mistral)
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")


def call_local_ollama(prompt: str, model: str = OLLAMA_MODEL) -> Optional[str]:
    """Generates grounded answer using local Ollama instance if running."""
    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.post(
                f"{OLLAMA_BASE_URL}/api/generate",
                json={
                    "model": model,
                    "prompt": prompt,
                    "stream": False
                }
            )
            if resp.status_code == 200:
                data = resp.json()
                return data.get("response", "").strip()
    except Exception:
        pass
    return None


def process_python_rag_query(query: str, category_filter: Optional[str] = "all") -> RAGQueryResponse:
    start_time = time.time()
    search_results: List[SearchResult] = python_vector_store.search(query, top_k=4, category_filter=category_filter)
    exec_time_ms = (time.time() - start_time) * 1000

    citations = [
        GroundedCitation(
            chunkId=r.chunk.id,
            docId=r.chunk.doc_id,
            docTitle=r.chunk.doc_title,
            category=r.chunk.category,
            sourceType=r.chunk.source_type,
            channelOrUrl=r.chunk.channel_or_url,
            snippet=r.chunk.text[:280] + "...",
            score=r.score
        )
        for r in search_results
    ]

    highest_score = search_results[0].score if search_results else 0.0
    is_gap = highest_score < 0.28 or len(search_results) == 0

    embedding_model_name = (
        "Sentence Transformers (all-MiniLM-L6-v2) + FAISS Index + BM25 Okapi"
        if _st_model is not None
        else "384-dim Dense Vector Index (FAISS/Cosine) + BM25 Okapi"
    )

    if is_gap:
        return RAGQueryResponse(
            answer=(
                f"I could not locate an authoritative answer for **\"{query}\"** in the indexed knowledge base.\n\n"
                "### 🔍 Recommended Escalation Channels:\n"
                "- **Engineering & Tooling**: Ask in `#eng-support` or tag `@platform-help`\n"
                "- **Access & IT**: Check Okta or ask in `#it-access-requests`\n"
                "- **HR & Benefits**: Reach out to People Ops in `#ask-people-ops`\n\n"
                "*This query has been recorded in the Knowledge Gaps tracker.*"
            ),
            citations=[],
            confidence="insufficient_knowledge",
            suggestedFollowUps=[
                "How do I request software access in #it-access-requests?",
                "Who is on-call for platform engineering?",
                "How do I contribute a new guide to the internal wiki?"
            ],
            actionSteps=[
                "Post inquiry to appropriate team Slack channel",
                "Tag your team onboarding buddy",
                "Check back once documentation is updated"
            ],
            contactPoint="#eng-support or #ask-people-ops",
            isKnowledgeGap=True,
            retrievalStats=RetrievalStats(
                totalChunksIndexed=len(python_vector_store.chunks),
                searchedChunks=len(python_vector_store.chunks),
                topMatchesCount=0,
                queryExecutionTimeMs=round(exec_time_ms, 2),
                embeddingModel=embedding_model_name
            )
        )

    # 1. Grounded synthesis: Try local Ollama LLM (Llama 3.2 / Mistral)
    context_blocks = "\n\n---\n\n".join([
        f"[Source: {r.chunk.doc_title} | Category: {r.chunk.category} | Dept: {r.chunk.department}]\n{r.chunk.text}"
        for r in search_results
    ])
    
    rag_prompt = (
        f"You are the internal Knowledge Assistant. Answer the user's question using ONLY the provided retrieved context.\n"
        f"Be direct, concise, and format CLI commands or policies in clean markdown.\n\n"
        f"Question: {query}\n\n"
        f"Retrieved Knowledge Context:\n{context_blocks}\n\n"
        f"Grounded Answer:"
    )

    synthesized_answer = call_local_ollama(rag_prompt)

    # 2. Structured Grounded Fallback if Ollama is not running
    if not synthesized_answer:
        primary_chunk = search_results[0].chunk
        clean_primary = re.sub(r'^\[Document:[^\]]+\]\n', '', primary_chunk.text).strip()
        
        synthesized_answer = (
            f"### Grounded Resolution from **{primary_chunk.doc_title}**\n"
            f"*Source: {primary_chunk.source_type.upper()} • {primary_chunk.channel_or_url or 'Internal'} ({primary_chunk.department})*\n\n"
            f"{clean_primary}"
        )

        if len(search_results) > 1 and search_results[1].score > 0.35:
            sec_chunk = search_results[1].chunk
            if sec_chunk.doc_id != primary_chunk.doc_id:
                clean_sec = re.sub(r'^\[Document:[^\]]+\]\n', '', sec_chunk.text).strip()
                synthesized_answer += (
                    f"\n\n---\n\n### 📌 Related Cross-Silo Context: **{sec_chunk.doc_title}**\n"
                    f"*Source: {sec_chunk.source_type.upper()} • {sec_chunk.channel_or_url or 'Internal'}*\n\n"
                    f"{clean_sec[:400]}..."
                )

    # Dynamic follow-ups
    q_lower = query.lower()
    if any(k in q_lower for k in ['docker', 'silicon', 'm1', 'm2', 'local', 'dev']):
        follow_ups = [
            "How do I configure Doppler secrets for local microservices?",
            "How can I seed my local Postgres with sanitized staging data?",
            "What are the branch naming rules for git PRs?"
        ]
    elif any(k in q_lower for k in ['401k', 'fidelity', 'match', 'benefit', 'equity', 'carta']):
        follow_ups = [
            "What is the 1-year cliff and vesting schedule for equity in Carta?",
            "How do I claim my $1,500 annual L&D stipend in Brex?",
            "How much does Acme contribute to the HSA health plan?"
        ]
    else:
        follow_ups = [
            "How do I configure Doppler secrets for local microservices?",
            "What is our 401(k) company match in Fidelity?",
            "How do I request elevated AWS permissions in Slack?"
        ]

    return RAGQueryResponse(
        answer=synthesized_answer,
        citations=citations,
        confidence="high" if highest_score > 0.5 else "medium",
        suggestedFollowUps=follow_ups,
        actionSteps=[
            "Review referenced internal documentation runbook",
            "Execute necessary CLI commands or portal requests",
            "Contact department lead if permission escalation is required"
        ],
        contactPoint="#eng-support or #ask-people-ops",
        isKnowledgeGap=False,
        retrievalStats=RetrievalStats(
            totalChunksIndexed=len(python_vector_store.chunks),
            searchedChunks=len(python_vector_store.chunks),
            topMatchesCount=len(search_results),
            queryExecutionTimeMs=round(exec_time_ms, 2),
            embeddingModel=embedding_model_name
        )
    )

