# Python FastAPI Local RAG Knowledge Assistant Backend

This directory contains the Python **FastAPI** backend powering the **Local RAG Pipeline** with open-source semantic embeddings, vector indexing, lexical ranking, and local LLM synthesis.

## 🚀 Key Architecture Components

1. **Semantic Embeddings**: `sentence-transformers` with `all-MiniLM-L6-v2` (384-dimensional dense vectors).
2. **Vector Retrieval**: **FAISS** (`IndexFlatIP` on normalized embeddings for cosine similarity).
3. **Lexical Keyword Search**: **BM25Okapi** (`rank-bm25`) for token frequency and exact technical term matching.
4. **Hybrid Ranker**: Weighted combination of Dense Semantic Similarity ($0.60$) and Sparse BM25 Keyword Score ($0.40$).
5. **Confidence & Knowledge Gap Detection**: Flags queries with retrieval scores $< 0.28$ as unanswered knowledge gaps and provides department escalation points.
6. **Local LLM Synthesis**: **Ollama** integration (`llama3.2` / `mistral`) for fully local grounded answer synthesis without cloud API dependencies.
7. **Pydantic v2 Validation**: Strict data schemas matching the React TypeScript frontend.

## 📦 Local Setup & Run

1. **Create and activate a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **(Optional) Run Ollama locally**:
   ```bash
   ollama pull llama3.2
   ollama serve
   ```

4. **Run the FastAPI server**:
   ```bash
   uvicorn main:app --reload --port 8000
   ```

5. **Interact with the API**:
   - Interactive OpenAPI Swagger Docs: `http://localhost:8000/docs`
   - Health Check: `http://localhost:8000/api/health`
   - POST RAG Query: `http://localhost:8000/api/rag/query`
   - POST Vector Search: `http://localhost:8000/api/rag/search`
