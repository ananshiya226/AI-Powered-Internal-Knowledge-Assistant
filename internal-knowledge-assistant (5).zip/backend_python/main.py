import os
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from schemas import (
    RAGQueryRequest,
    RAGQueryResponse,
    KnowledgeDocument,
    SearchResult
)
from rag_service import process_python_rag_query
from vector_store import python_vector_store

load_dotenv()

app = FastAPI(
    title="Nexus Enterprise Onboarding RAG Assistant API",
    description="Python FastAPI backend providing vector embeddings, semantic retrieval, and LLM synthesis over company knowledge silos.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "service": "Python FastAPI RAG Backend",
        "documents_count": len(python_vector_store.documents),
        "chunks_count": len(python_vector_store.chunks)
    }

@app.post("/api/rag/query", response_model=RAGQueryResponse)
def query_rag(payload: RAGQueryRequest):
    if not payload.query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty")
    return process_python_rag_query(payload.query, payload.category_filter)

@app.post("/api/rag/search", response_model=List[SearchResult])
def search_vector_store(query: str, top_k: int = 4, category_filter: Optional[str] = "all"):
    return python_vector_store.search(query, top_k=top_k, category_filter=category_filter)

@app.get("/api/docs", response_model=List[KnowledgeDocument])
def list_documents():
    return list(python_vector_store.documents.values())

@app.post("/api/docs", response_model=KnowledgeDocument)
def ingest_document(doc: KnowledgeDocument):
    return python_vector_store.add_document(doc)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
