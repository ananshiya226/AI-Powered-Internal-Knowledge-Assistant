export type SourceCategory = 'engineering' | 'hr_people' | 'slack_threads' | 'security_it' | 'product_wiki' | 'glossary';

export interface DocumentMetadata {
  id: string;
  title: string;
  category: SourceCategory;
  sourceType: 'wiki' | 'slack' | 'notion' | 'rfc' | 'policy' | 'faq';
  author: string;
  lastUpdated: string;
  channelOrUrl?: string;
  tags: string[];
  department: string;
}

export interface KnowledgeDocument extends DocumentMetadata {
  content: string;
  chunkCount?: number;
}

export interface DocumentChunk {
  id: string;
  docId: string;
  docTitle: string;
  category: SourceCategory;
  sourceType: string;
  department: string;
  channelOrUrl?: string;
  chunkIndex: number;
  totalChunks: number;
  text: string;
  tokenCount: number;
  embedding?: number[];
}

export interface SearchResult {
  chunk: DocumentChunk;
  score: number;
  vectorScore: number;
  keywordScore: number;
  matchedKeywords: string[];
}

export interface GroundedCitation {
  chunkId: string;
  docId: string;
  docTitle: string;
  category: SourceCategory;
  sourceType: string;
  channelOrUrl?: string;
  snippet: string;
  score: number;
}

export interface AssistantResponse {
  answer: string;
  citations: GroundedCitation[];
  confidence: 'high' | 'medium' | 'low' | 'insufficient_knowledge';
  suggestedFollowUps: string[];
  actionSteps?: string[];
  contactPoint?: string;
  isKnowledgeGap: boolean;
  retrievalStats: {
    totalChunksIndexed: number;
    searchedChunks: number;
    topMatchesCount: number;
    queryExecutionTimeMs: number;
    embeddingModel: string;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  citations?: GroundedCitation[];
  confidence?: 'high' | 'medium' | 'low' | 'insufficient_knowledge';
  suggestedFollowUps?: string[];
  actionSteps?: string[];
  contactPoint?: string;
  isKnowledgeGap?: boolean;
  retrievalStats?: AssistantResponse['retrievalStats'];
  categoryFilter?: SourceCategory | 'all';
}

export interface OnboardingTask {
  id: string;
  category: 'day_1' | 'week_1' | 'month_1';
  title: string;
  description: string;
  completed: boolean;
  department: 'All' | 'Engineering' | 'Product' | 'Operations';
  queryPrompt: string;
  relatedDocId?: string;
}

export interface KnowledgeGapItem {
  id: string;
  query: string;
  timestamp: string;
  category: string;
  status: 'open' | 'in_review' | 'resolved';
  suggestedDocTitle: string;
  frequency: number;
}

export interface SystemStats {
  totalDocuments: number;
  totalChunks: number;
  categoriesCount: Record<SourceCategory, number>;
  totalQueriesProcessed: number;
  knowledgeGapsIdentified: number;
  averageRetrievalTimeMs: number;
}
