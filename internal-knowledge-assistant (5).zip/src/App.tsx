import React, { useState, useEffect } from 'react';
import { Navbar, ActiveTab } from './components/Navbar';
import { AssistantChat } from './components/AssistantChat';
import { OnboardingChecklist } from './components/OnboardingChecklist';
import { KnowledgeExplorer } from './components/KnowledgeExplorer';
import { VectorPlayground } from './components/VectorPlayground';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { PythonFastAPIViewer } from './components/PythonFastAPIViewer';
import { SystemStats } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('chat');
  const defaultStats: SystemStats = {
    totalDocuments: 10,
    totalChunks: 37,
    categoriesCount: {
      engineering: 4,
      hr_people: 2,
      slack_threads: 2,
      security_it: 1,
      product_wiki: 1,
      glossary: 0,
    },
    totalQueriesProcessed: 4,
    knowledgeGapsIdentified: 2,
    averageRetrievalTimeMs: 18,
  };

  const [stats, setStats] = useState<SystemStats>(defaultStats);
  const [chatPrompt, setChatPrompt] = useState<string>('');

  const fetchStats = async (retries = 3, delay = 800) => {
    for (let i = 0; i < retries; i++) {
      try {
        const res = await fetch('/api/analytics/stats');
        if (res.ok) {
          const data = await res.json();
          setStats(data);
          return;
        }
      } catch (err) {
        if (i < retries - 1) {
          await new Promise(r => setTimeout(r, delay * (i + 1)));
        }
      }
    }
  };

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleAskAIFromChecklist = (prompt: string) => {
    setChatPrompt(prompt);
    setActiveTab('chat');
  };

  const handleNavigateToDocs = () => {
    setActiveTab('knowledge');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation Bar */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} stats={stats} />

      {/* Main Tab Views */}
      <main className="flex-1">
        {activeTab === 'chat' && (
          <AssistantChat
            initialPrompt={chatPrompt}
            onClearInitialPrompt={() => setChatPrompt('')}
          />
        )}

        {activeTab === 'onboarding' && (
          <OnboardingChecklist onAskAI={handleAskAIFromChecklist} />
        )}

        {activeTab === 'knowledge' && (
          <KnowledgeExplorer onRefreshStats={fetchStats} />
        )}

        {activeTab === 'vector' && (
          <VectorPlayground />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsDashboard stats={stats} onNavigateToDocs={handleNavigateToDocs} />
        )}

        {activeTab === 'python' && (
          <PythonFastAPIViewer />
        )}
      </main>
    </div>
  );
}
