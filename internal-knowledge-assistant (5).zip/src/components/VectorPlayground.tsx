import React, { useState } from 'react';
import { 
  Search, 
  Sparkles, 
  Layers, 
  Cpu, 
  Sliders, 
  FileText, 
  ArrowRight, 
  CheckCircle,
  Hash,
  Activity
} from 'lucide-react';
import { SearchResult, SourceCategory } from '../types';

export const VectorPlayground: React.FC = () => {
  const [testQuery, setTestQuery] = useState('How to fix Docker Apple Silicon architecture build error');
  const [topK, setTopK] = useState(4);
  const [categoryFilter, setCategoryFilter] = useState<SourceCategory | 'all'>('all');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [latencyMs, setLatencyMs] = useState<number | null>(null);

  const handleTestSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!testQuery.trim()) return;

    setIsLoading(true);
    setHasSearched(true);
    const start = performance.now();

    try {
      const res = await fetch('/api/rag/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: testQuery.trim(),
          topK,
          categoryFilter,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setResults(data.results || []);
      }
    } catch (err) {
      console.error('Vector search error:', err);
    } finally {
      setLatencyMs(Math.round(performance.now() - start));
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center space-x-2 text-indigo-400 text-xs font-semibold uppercase tracking-wider mb-1">
          <Cpu className="w-4 h-4" />
          <span>Vector Search & Dense Retrieval Diagnostics</span>
        </div>
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Vector Embeddings & Semantic Search Playground
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-2xl">
          Test semantic cosine similarity calculations and hybrid dense-token rankings across indexed chunks before LLM generation.
        </p>

        {/* Query Input Bar */}
        <form onSubmit={handleTestSearch} className="mt-6 space-y-4">
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={testQuery}
                onChange={(e) => setTestQuery(e.target.value)}
                placeholder="Enter query to inspect vector cosine match..."
                className="w-full bg-slate-950 border border-slate-700 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-100 placeholder-slate-500 outline-hidden shadow-inner"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full sm:w-auto px-6 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              {isLoading ? (
                <span>Computing Cosine Vectors...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Test Retrieval</span>
                </>
              )}
            </button>
          </div>

          {/* Controls: Top-K & Category Filter */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-800/80 text-xs">
            <div className="flex items-center space-x-3">
              <span className="text-slate-400 flex items-center">
                <Sliders className="w-3.5 h-3.5 mr-1 text-indigo-400" />
                Top-K Chunks: <strong className="text-white ml-1 font-mono">{topK}</strong>
              </span>
              <input
                type="range"
                min="1"
                max="8"
                value={topK}
                onChange={(e) => setTopK(Number(e.target.value))}
                className="w-28 accent-indigo-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-slate-400">Filter Domain:</span>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value as any)}
                className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-hidden focus:border-indigo-500"
              >
                <option value="all">All Knowledge Silos</option>
                <option value="engineering">Engineering</option>
                <option value="hr_people">HR & Benefits</option>
                <option value="slack_threads">Slack Threads</option>
                <option value="security_it">Security & IT</option>
                <option value="product_wiki">Product & RFCs</option>
                <option value="glossary">Glossary</option>
              </select>
            </div>
          </div>
        </form>
      </div>

      {/* Preset Test Queries */}
      <div className="flex items-center space-x-2 overflow-x-auto py-1">
        <span className="text-xs text-slate-400 whitespace-nowrap">Try queries:</span>
        {[
          'Apple Silicon Docker exec format error',
          'Fidelity 401k safe harbor matching formula',
          'Teleport tsh bastion access and elevated AWS IAM',
          'Learning & Development 1500 stipend Brex policy',
          'Sanitized staging database dump script',
        ].map((sample, sIdx) => (
          <button
            key={sIdx}
            onClick={() => {
              setTestQuery(sample);
            }}
            className="text-[11px] bg-slate-900 hover:bg-slate-800 border border-slate-800 text-indigo-300 px-3 py-1 rounded-lg transition-colors whitespace-nowrap"
          >
            {sample}
          </button>
        ))}
      </div>

      {/* Search Results Display */}
      {hasSearched && (
        <div className="space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              <h3 className="font-semibold text-white text-sm">
                Retrieved Vector Chunks ({results.length} Matches)
              </h3>
            </div>
            {latencyMs !== null && (
              <span className="text-xs font-mono text-emerald-400 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg flex items-center space-x-1">
                <Activity className="w-3 h-3 mr-1" />
                <span>Retrieval Latency: {latencyMs}ms</span>
              </span>
            )}
          </div>

          {results.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
              No matching chunks found above threshold for this domain filter.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {results.map((result, idx) => (
                <div
                  key={result.chunk.id}
                  className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-md space-y-3 transition-all"
                >
                  {/* Result Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                    <div className="flex items-center space-x-3">
                      <div className="w-7 h-7 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center font-mono font-bold text-xs">
                        #{idx + 1}
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-white">
                          {result.chunk.docTitle}
                        </h4>
                        <span className="text-xs text-slate-400 font-mono">
                          Chunk {result.chunk.chunkIndex} of {result.chunk.totalChunks || 1} • {result.chunk.department} ({result.chunk.sourceType})
                        </span>
                      </div>
                    </div>

                    {/* Scores Badges */}
                    <div className="flex items-center space-x-2">
                      <div className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-right">
                        <span className="text-[10px] text-slate-500 uppercase block">Combined</span>
                        <span className="text-xs font-mono font-bold text-emerald-400">
                          {(result.score * 100).toFixed(1)}%
                        </span>
                      </div>

                      <div className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-right">
                        <span className="text-[10px] text-slate-500 uppercase block">Vector Cosine</span>
                        <span className="text-xs font-mono text-indigo-400">
                          {(result.vectorScore * 100).toFixed(1)}%
                        </span>
                      </div>

                      <div className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-right">
                        <span className="text-[10px] text-slate-500 uppercase block">Keyword</span>
                        <span className="text-xs font-mono text-amber-400">
                          {(result.keywordScore * 100).toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Chunk Text Box */}
                  <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-200 leading-relaxed whitespace-pre-wrap">
                    {result.chunk.text}
                  </div>

                  {/* Keywords Matched */}
                  {result.matchedKeywords && result.matchedKeywords.length > 0 && (
                    <div className="flex items-center space-x-2 text-xs text-slate-400">
                      <Hash className="w-3.5 h-3.5 text-amber-400" />
                      <span>Matched tokens:</span>
                      <div className="flex flex-wrap gap-1">
                        {result.matchedKeywords.map((kw, kIdx) => (
                          <span key={kIdx} className="px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 font-mono text-[10px] border border-amber-500/20">
                            {kw}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
