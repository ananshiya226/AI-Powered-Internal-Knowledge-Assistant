import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Database, 
  TrendingUp, 
  FileText, 
  Layers, 
  Plus, 
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { KnowledgeGapItem, SystemStats } from '../types';

interface AnalyticsDashboardProps {
  stats: SystemStats | null;
  onNavigateToDocs: () => void;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ stats, onNavigateToDocs }) => {
  const [gaps, setGaps] = useState<KnowledgeGapItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchGaps();
  }, []);

  const fetchGaps = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/analytics/gaps');
      if (res.ok) {
        const data = await res.json();
        setGaps(data);
      }
    } catch (err) {
      console.error('Failed to fetch gaps:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const updateGapStatus = async (id: string, newStatus: 'open' | 'in_review' | 'resolved') => {
    try {
      const res = await fetch(`/api/analytics/gaps/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        setGaps(prev => prev.map(g => g.id === id ? { ...g, status: newStatus } : g));
      }
    } catch (err) {
      console.error('Failed to update gap status:', err);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center space-x-2 text-indigo-400 text-xs font-semibold uppercase tracking-wider mb-1">
          <BarChart3 className="w-4 h-4" />
          <span>Knowledge Base Observability & Gap Detection</span>
        </div>
        <h2 className="text-2xl font-bold text-white tracking-tight">
          Knowledge Silo Analytics & Gap Tracker
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-2xl">
          Track employee query patterns, vector retrieval metrics, and automatically detect missing documentation across company departments.
        </p>
      </div>

      {/* Top 4 Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Total Documents</span>
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {stats?.totalDocuments || 0}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Across 6 department silos
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Vector Chunks Indexed</span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {stats?.totalChunks || 0}
          </div>
          <span className="text-[11px] text-emerald-400 mt-1 block flex items-center">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1"></span>
            100% Vectorized in memory
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Queries Resolved</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {stats?.totalQueriesProcessed || 0}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Avg retrieval latency: ~{stats?.averageRetrievalTimeMs || 24}ms
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Knowledge Gaps Flagged</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-amber-300 font-mono">
            {gaps.length}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Awaiting wiki documentation
          </span>
        </div>
      </div>

      {/* Silo Source Distribution */}
      {stats?.categoriesCount && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md">
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4 flex items-center space-x-2">
            <Database className="w-4 h-4 text-indigo-400" />
            <span>Knowledge Distribution Across Company Silos</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {[
              { label: 'Engineering Wiki', count: stats.categoriesCount.engineering || 0, color: 'text-blue-400' },
              { label: 'HR & Benefits', count: stats.categoriesCount.hr_people || 0, color: 'text-emerald-400' },
              { label: 'Slack Archives', count: stats.categoriesCount.slack_threads || 0, color: 'text-amber-400' },
              { label: 'Security & Access', count: stats.categoriesCount.security_it || 0, color: 'text-purple-400' },
              { label: 'Architecture RFCs', count: stats.categoriesCount.product_wiki || 0, color: 'text-cyan-400' },
              { label: 'Acronyms Glossary', count: stats.categoriesCount.glossary || 0, color: 'text-rose-400' },
            ].map((cat, idx) => (
              <div key={idx} className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-3.5 flex flex-col justify-between">
                <span className="text-xs text-slate-400 leading-snug">{cat.label}</span>
                <span className={`text-xl font-bold font-mono ${cat.color} mt-2`}>
                  {cat.count} docs
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Knowledge Gaps Table / Card List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Unanswered Questions & Missing Documentation Gaps</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              When new hires ask questions that cannot be resolved with high confidence, Nexus automatically logs the query here so documentation owners can author a runbook.
            </p>
          </div>

          <button
            onClick={onNavigateToDocs}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 text-xs font-semibold transition-all self-start sm:self-auto cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Author Missing Doc</span>
          </button>
        </div>

        {isLoading ? (
          <div className="py-8 text-center text-xs text-slate-400">Loading gap records...</div>
        ) : gaps.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500">
            No knowledge gaps detected. All queries have authoritative sources!
          </div>
        ) : (
          <div className="space-y-3">
            {gaps.map((gap) => (
              <div
                key={gap.id}
                className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-xs text-white">
                      &quot;{gap.query}&quot;
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                      Asked {gap.frequency}x
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
                    <span>Category: <strong className="text-slate-300 capitalize">{gap.category.replace('_', ' ')}</strong></span>
                    <span>•</span>
                    <span>Suggested Title: <strong className="text-indigo-300">{gap.suggestedDocTitle}</strong></span>
                  </div>
                </div>

                {/* Status Toggle Buttons */}
                <div className="flex items-center space-x-2 self-end md:self-center shrink-0">
                  <span className="text-xs text-slate-500 mr-1">Status:</span>
                  <button
                    onClick={() => updateGapStatus(gap.id, 'open')}
                    className={`text-xs px-2.5 py-1 rounded-lg font-medium transition-colors ${
                      gap.status === 'open'
                        ? 'bg-rose-600 text-white font-bold'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    Open
                  </button>
                  <button
                    onClick={() => updateGapStatus(gap.id, 'in_review')}
                    className={`text-xs px-2.5 py-1 rounded-lg font-medium transition-colors ${
                      gap.status === 'in_review'
                        ? 'bg-amber-600 text-white font-bold'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    In Review
                  </button>
                  <button
                    onClick={() => updateGapStatus(gap.id, 'resolved')}
                    className={`text-xs px-2.5 py-1 rounded-lg font-medium transition-colors ${
                      gap.status === 'resolved'
                        ? 'bg-emerald-600 text-white font-bold'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    Resolved
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
