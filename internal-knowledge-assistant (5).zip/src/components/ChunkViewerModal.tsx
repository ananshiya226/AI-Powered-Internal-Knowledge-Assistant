import React from 'react';
import { X, ExternalLink, Hash, FileText, CheckCircle, Tag, Layers } from 'lucide-react';
import { GroundedCitation } from '../types';

interface ChunkViewerModalProps {
  citation: GroundedCitation | null;
  onClose: () => void;
}

export const ChunkViewerModal: React.FC<ChunkViewerModalProps> = ({ citation, onClose }) => {
  if (!citation) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-white text-base truncate max-w-md">
                {citation.docTitle}
              </h3>
              <div className="flex items-center space-x-2 text-xs text-slate-400 mt-0.5">
                <span className="capitalize px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                  {citation.sourceType}
                </span>
                <span>•</span>
                <span className="text-indigo-400 font-medium">Chunk #{citation.chunkId}</span>
              </div>
            </div>
          </div>
          <button
            id="close-chunk-modal"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* Metadata Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
              <span className="text-xs text-slate-400 block mb-1">Retrieval Score</span>
              <div className="flex items-center space-x-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400"></div>
                <span className="text-emerald-400 font-mono font-bold text-sm">
                  {(citation.score * 100).toFixed(1)}% Match
                </span>
              </div>
            </div>

            <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
              <span className="text-xs text-slate-400 block mb-1">Knowledge Category</span>
              <span className="text-slate-200 font-medium text-xs capitalize">
                {citation.category.replace('_', ' ')}
              </span>
            </div>

            <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3 col-span-2 sm:col-span-1">
              <span className="text-xs text-slate-400 block mb-1">Source Channel / URL</span>
              <span className="text-indigo-300 font-mono text-xs truncate block" title={citation.channelOrUrl}>
                {citation.channelOrUrl || 'Internal Wiki'}
              </span>
            </div>
          </div>

          {/* Raw Chunk Content */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                <Layers className="w-3.5 h-3.5 text-indigo-400" />
                <span>Grounded Knowledge Context Chunk</span>
              </span>
              <span className="text-xs text-slate-500">Indexed for Vector Cosine Retrieval</span>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-slate-200 leading-relaxed whitespace-pre-wrap selection:bg-indigo-500 selection:text-white">
              {citation.snippet}
            </div>
          </div>

          {/* Grounding Attribution Info */}
          <div className="bg-indigo-950/40 border border-indigo-500/20 rounded-xl p-4 text-xs text-indigo-200 flex items-start space-x-3">
            <CheckCircle className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-white mb-0.5">Direct Vector Grounding Reference</p>
              <p className="text-indigo-300/80 leading-normal">
                This exact text block was retrieved by the vector semantic search engine and injected into Gemini&apos;s context window to construct the factual answer with zero hallucination.
              </p>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/90 flex items-center justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg transition-colors"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
