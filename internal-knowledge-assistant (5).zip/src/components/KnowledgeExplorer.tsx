import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { 
  Database, 
  Search, 
  Plus, 
  Trash2, 
  FileText, 
  Layers, 
  Calendar, 
  User, 
  Tag, 
  ExternalLink, 
  X, 
  Check, 
  MessageSquare, 
  BookOpen, 
  Shield, 
  Briefcase,
  AlertCircle
} from 'lucide-react';
import { KnowledgeDocument, SourceCategory } from '../types';

interface KnowledgeExplorerProps {
  onRefreshStats: () => void;
}

export const KnowledgeExplorer: React.FC<KnowledgeExplorerProps> = ({ onRefreshStats }) => {
  const [documents, setDocuments] = useState<KnowledgeDocument[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<SourceCategory | 'all'>('all');
  const [selectedDoc, setSelectedDoc] = useState<KnowledgeDocument | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // New Document Form State
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<SourceCategory>('engineering');
  const [newSourceType, setNewSourceType] = useState<string>('wiki');
  const [newDepartment, setNewDepartment] = useState('Engineering');
  const [newChannelOrUrl, setNewChannelOrUrl] = useState('');
  const [newAuthor, setNewAuthor] = useState('');
  const [newTags, setNewTags] = useState('');
  const [newContent, setNewContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchDocuments();
  }, []);

  const fetchDocuments = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/docs');
      if (res.ok) {
        const data = await res.json();
        setDocuments(data);
        if (data.length > 0 && !selectedDoc) {
          setSelectedDoc(data[0]);
        }
      }
    } catch (err) {
      console.error('Failed to fetch documents:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    try {
      setIsSubmitting(true);
      const res = await fetch('/api/docs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle.trim(),
          category: newCategory,
          sourceType: newSourceType,
          department: newDepartment,
          channelOrUrl: newChannelOrUrl.trim(),
          author: newAuthor.trim() || 'Knowledge Contributor',
          tags: newTags.split(',').map(t => t.trim()).filter(Boolean),
          content: newContent.trim(),
        }),
      });

      if (res.ok) {
        const added = await res.json();
        setDocuments(prev => [added, ...prev]);
        setSelectedDoc(added);
        setIsAddModalOpen(false);
        // Reset form
        setNewTitle('');
        setNewContent('');
        setNewChannelOrUrl('');
        setNewTags('');
        onRefreshStats();
      }
    } catch (err) {
      console.error('Failed to add document:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteDocument = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this document from the vector knowledge store?')) return;

    try {
      const res = await fetch(`/api/docs/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setDocuments(prev => prev.filter(d => d.id !== id));
        if (selectedDoc?.id === id) {
          setSelectedDoc(documents.find(d => d.id !== id) || null);
        }
        onRefreshStats();
      }
    } catch (err) {
      console.error('Failed to delete doc:', err);
    }
  };

  const filteredDocs = documents.filter(d => {
    const matchesCategory = selectedCategory === 'all' || d.category === selectedCategory;
    const matchesSearch = 
      d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const getCategoryIcon = (category: SourceCategory) => {
    switch (category) {
      case 'engineering': return <BookOpen className="w-4 h-4 text-blue-400" />;
      case 'hr_people': return <Briefcase className="w-4 h-4 text-emerald-400" />;
      case 'slack_threads': return <MessageSquare className="w-4 h-4 text-amber-400" />;
      case 'security_it': return <Shield className="w-4 h-4 text-purple-400" />;
      default: return <FileText className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-indigo-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <Database className="w-4 h-4" />
            <span>Vector Indexed Knowledge Silos</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Company Knowledge Repository
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Internal Confluence guides, HR handbooks, Slack transcripts, and architectural RFCs.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/20 transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Ingest New Document / Slack Thread</span>
        </button>
      </div>

      {/* Synthetic Demo Data Notice */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl px-4 py-2.5 flex items-center justify-between gap-3 text-xs text-slate-400">
        <div className="flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>
            <strong className="text-slate-300">Demo Knowledge Base:</strong> All policies, credentials, company names, and Slack threads are synthetic data crafted for educational and portfolio demonstration.
          </span>
        </div>
        <span className="text-[11px] font-mono text-indigo-300 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40 hidden md:inline">
          In-Memory Vector Store
        </span>
      </div>

      {/* Main Split View: Left Doc List, Right Doc Reader */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Side: Filter & Document List (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-4">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search documents, tags, acronyms..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-500 outline-hidden"
            />
          </div>

          {/* Category Filter Chips */}
          <div className="flex flex-wrap gap-1.5 pb-2 border-b border-slate-800">
            {[
              { id: 'all', label: 'All Sources' },
              { id: 'engineering', label: 'Engineering' },
              { id: 'hr_people', label: 'HR/Benefits' },
              { id: 'slack_threads', label: 'Slack Archives' },
              { id: 'security_it', label: 'Security/IT' },
              { id: 'product_wiki', label: 'RFCs' },
              { id: 'glossary', label: 'Glossary' },
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as any)}
                className={`text-[11px] px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Document Cards List */}
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {isLoading ? (
              <div className="text-center py-8 text-xs text-slate-400">Loading knowledge base...</div>
            ) : filteredDocs.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500">No documents match your query.</div>
            ) : (
              filteredDocs.map(doc => {
                const isSelected = selectedDoc?.id === doc.id;
                return (
                  <div
                    key={doc.id}
                    onClick={() => setSelectedDoc(doc)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-slate-800/90 border-indigo-500 text-white shadow-xs'
                        : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <div className="flex items-center space-x-2">
                        <div className="p-1 rounded bg-slate-900 border border-slate-800">
                          {getCategoryIcon(doc.category)}
                        </div>
                        <h4 className="font-semibold text-xs text-white leading-tight line-clamp-1">
                          {doc.title}
                        </h4>
                      </div>
                      <button
                        onClick={(e) => handleDeleteDocument(doc.id, e)}
                        className="text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-slate-900 transition-colors"
                        title="Delete document"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
                      <span className="font-mono text-indigo-400">
                        {doc.chunkCount || 1} Chunks
                      </span>
                      <span>{doc.department}</span>
                      <span>{doc.lastUpdated}</span>
                    </div>

                    {/* Tag Pills */}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {doc.tags.slice(0, 3).map((tag, tIdx) => (
                        <span key={tIdx} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800 font-mono">
                          #{tag}
                        </span>
                      ))}
                      {doc.tags.length > 3 && (
                        <span className="text-[10px] text-slate-500">+{doc.tags.length - 3}</span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Side: Selected Document Viewer (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md">
          {selectedDoc ? (
            <div className="space-y-4">
              {/* Document Header & Metadata */}
              <div className="pb-4 border-b border-slate-800">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-mono uppercase bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    {selectedDoc.sourceType} • {selectedDoc.category.replace('_', ' ')}
                  </span>
                  <span className="text-xs text-slate-400">
                    Dept: <strong className="text-slate-200">{selectedDoc.department}</strong>
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white tracking-tight">
                  {selectedDoc.title}
                </h3>

                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 mt-2">
                  <div className="flex items-center space-x-1">
                    <User className="w-3.5 h-3.5 text-slate-500" />
                    <span>{selectedDoc.author}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>Updated {selectedDoc.lastUpdated}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Layers className="w-3.5 h-3.5 text-indigo-400" />
                    <span className="font-mono text-indigo-300">{selectedDoc.chunkCount || 1} Vector Chunks</span>
                  </div>
                </div>

                {selectedDoc.channelOrUrl && (
                  <div className="mt-2 text-xs text-indigo-300/80 font-mono bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 flex items-center justify-between">
                    <span className="truncate mr-2">Source: {selectedDoc.channelOrUrl}</span>
                    <ExternalLink className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  </div>
                )}
              </div>

              {/* Document Markdown Content */}
              <div className="prose prose-invert prose-sm max-w-none max-h-[500px] overflow-y-auto pr-2">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {selectedDoc.content}
                </ReactMarkdown>
              </div>
            </div>
          ) : (
            <div className="text-center py-20 text-slate-500">
              <FileText className="w-10 h-10 mx-auto text-slate-600 mb-2" />
              <p>Select a document from the left to read its contents and examine vector chunks.</p>
            </div>
          )}
        </div>
      </div>

      {/* Ingest Document Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Plus className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-white text-base">Ingest Knowledge Document</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddDocument} className="p-6 overflow-y-auto space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Document Title *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. AWS Staging Bastion Runbook or Slack Thread: Docker M1 Fix"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white outline-hidden"
                  >
                    <option value="engineering">Engineering</option>
                    <option value="hr_people">HR & Benefits</option>
                    <option value="slack_threads">Slack Threads</option>
                    <option value="security_it">Security & IT</option>
                    <option value="product_wiki">Product & RFCs</option>
                    <option value="glossary">Glossary</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Source Type</label>
                  <select
                    value={newSourceType}
                    onChange={(e) => setNewSourceType(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white outline-hidden"
                  >
                    <option value="wiki">Confluence Wiki</option>
                    <option value="slack">Slack Channel / Thread</option>
                    <option value="notion">Notion Policy</option>
                    <option value="rfc">Architecture RFC</option>
                    <option value="policy">HR Policy</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Department</label>
                  <input
                    type="text"
                    value={newDepartment}
                    onChange={(e) => setNewDepartment(e.target.value)}
                    placeholder="Engineering / HR"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Channel, URL, or Jira Link
                  </label>
                  <input
                    type="text"
                    value={newChannelOrUrl}
                    onChange={(e) => setNewChannelOrUrl(e.target.value)}
                    placeholder="#eng-support or https://wiki.internal.acme.co/..."
                    className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Author / Lead
                  </label>
                  <input
                    type="text"
                    value={newAuthor}
                    onChange={(e) => setNewAuthor(e.target.value)}
                    placeholder="e.g. Elena Rostova"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={newTags}
                  onChange={(e) => setNewTags(e.target.value)}
                  placeholder="docker, macos, staging, benefits, 401k"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Document Content (Markdown, text, or Slack transcript) *
                </label>
                <textarea
                  required
                  rows={8}
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="# Guide Title&#10;&#10;Explain the steps or paste the resolved Slack thread..."
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl p-3 font-mono text-xs text-white placeholder-slate-600 outline-hidden leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-md transition-all flex items-center space-x-1.5"
                >
                  {isSubmitting ? (
                    <span>Chunking & Vectorizing...</span>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Ingest & Vectorize</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
