import React from 'react';
import { 
  Bot, 
  CheckSquare, 
  Database, 
  Search, 
  BarChart3, 
  Code2, 
  Sparkles,
  Layers
} from 'lucide-react';
import { SystemStats } from '../types';

export type ActiveTab = 'chat' | 'onboarding' | 'knowledge' | 'vector' | 'analytics' | 'python';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  stats: SystemStats | null;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, stats }) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900 border-b border-slate-800 text-slate-100 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Assistant Identity */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-white/10">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg text-white tracking-tight">Nexus</span>
                <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  RAG Enterprise Assistant
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Onboarding & Knowledge Silo Resolver (Docs • Slack • Wiki)
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center space-x-1 sm:space-x-2 overflow-x-auto py-2">
            <button
              id="nav-tab-chat"
              onClick={() => setActiveTab('chat')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'chat'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span>AI Assistant</span>
            </button>

            <button
              id="nav-tab-onboarding"
              onClick={() => setActiveTab('onboarding')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'onboarding'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <CheckSquare className="w-4 h-4" />
              <span className="hidden md:inline">30-60-90</span>
              <span>Onboarding</span>
            </button>

            <button
              id="nav-tab-knowledge"
              onClick={() => setActiveTab('knowledge')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'knowledge'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>Knowledge Silos</span>
            </button>

            <button
              id="nav-tab-vector"
              onClick={() => setActiveTab('vector')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'vector'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Search className="w-4 h-4" />
              <span className="hidden lg:inline">Vector</span>
              <span>Playground</span>
            </button>

            <button
              id="nav-tab-analytics"
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'analytics'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span className="hidden md:inline">Gaps &</span>
              <span>Analytics</span>
            </button>

            <button
              id="nav-tab-python"
              onClick={() => setActiveTab('python')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'python'
                  ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                  : 'text-emerald-400 hover:text-emerald-300 hover:bg-slate-800 border border-emerald-500/20'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>FastAPI Spec</span>
            </button>
          </nav>

          {/* Quick Stats Pill */}
          <div className="hidden xl:flex items-center space-x-3 text-xs bg-slate-800/80 border border-slate-700/60 rounded-full px-3 py-1.5">
            <div className="flex items-center space-x-1.5 text-slate-300">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              <span>
                <strong className="text-white">{stats?.totalChunks || 0}</strong> chunks indexed
              </span>
            </div>
            <span className="text-slate-600">•</span>
            <div className="flex items-center space-x-1 text-emerald-400 font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>RAG Retrieval Live</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
