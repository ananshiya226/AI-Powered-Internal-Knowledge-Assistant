import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { 
  Bot, 
  User, 
  Send, 
  Sparkles, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  HelpCircle, 
  ExternalLink, 
  Copy, 
  Check, 
  RefreshCw, 
  Terminal, 
  Hash, 
  Briefcase, 
  Shield, 
  MessageSquare,
  ArrowRight,
  Filter
} from 'lucide-react';
import { ChatMessage, GroundedCitation, SourceCategory } from '../types';
import { ChunkViewerModal } from './ChunkViewerModal';

interface AssistantChatProps {
  initialPrompt?: string;
  onClearInitialPrompt?: () => void;
}

const STARTER_QUERIES = [
  {
    role: 'Software Engineer',
    icon: Terminal,
    color: 'from-blue-500/20 to-indigo-500/20 text-blue-400 border-blue-500/30',
    queries: [
      'How do I resolve Apple Silicon Docker exec format errors?',
      'How do I setup Doppler secrets for local microservices?',
      'How can I pull sanitized staging database seed data?',
    ]
  },
  {
    role: 'HR & Benefits',
    icon: Briefcase,
    color: 'from-emerald-500/20 to-teal-500/20 text-emerald-400 border-emerald-500/30',
    queries: [
      'What is Acme\'s 401(k) retirement match formula and vesting?',
      'How do I claim the $1,500 annual L&D stipend in Brex?',
      'What are our paid holidays and flexible time off policy?',
    ]
  },
  {
    role: 'Security & Access',
    icon: Shield,
    color: 'from-purple-500/20 to-violet-500/20 text-purple-400 border-purple-500/30',
    queries: [
      'How do I connect to staging Kubernetes via Teleport tsh?',
      'How do I request temporary 4-hour AWS IAM access?',
      'Where do I find my squad\'s 1Password team vault?',
    ]
  },
  {
    role: 'Slack Silos & RFCs',
    icon: MessageSquare,
    color: 'from-amber-500/20 to-orange-500/20 text-amber-400 border-amber-500/30',
    queries: [
      'What is the deadline for submitting monthly Brex expenses?',
      'What is RFC-042 and how does Kafka event bus work?',
      'What does internal acronym CAP and DRP stand for?',
    ]
  }
];

export const AssistantChat: React.FC<AssistantChatProps> = ({ initialPrompt, onClearInitialPrompt }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-msg',
      role: 'assistant',
      content: `👋 **Welcome to Nexus!** I am your internal AI knowledge assistant.\n\nI break down internal knowledge silos by indexing company documentation, Confluence wikis, Notion policies, and resolved Slack threads across **Engineering**, **HR & Benefits**, **IT/Security**, and **Architecture RFCs**.\n\nAsk me any question below or click a starter prompt to get started!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedFollowUps: [
        'How do I set up Doppler secrets for local development?',
        'What is our 401(k) company match in Fidelity?',
        'How do I request elevated AWS permissions in Slack?',
      ]
    }
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<SourceCategory | 'all'>('all');
  const [inspectCitation, setInspectCitation] = useState<GroundedCitation | null>(null);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom of conversation
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Handle external prompts (e.g. from onboarding checklist)
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim().length > 0) {
      handleSend(initialPrompt);
      if (onClearInitialPrompt) onClearInitialPrompt();
    }
  }, [initialPrompt]);

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      categoryFilter: selectedCategory,
    };

    setMessages(prev => [...prev, userMessage]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/rag/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: textToSend.trim(),
          categoryFilter: selectedCategory,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned error ${res.status}`);
      }

      const data = await res.json();

      const assistantMessage: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        citations: data.citations,
        confidence: data.confidence,
        suggestedFollowUps: data.suggestedFollowUps,
        actionSteps: data.actionSteps,
        contactPoint: data.contactPoint,
        isKnowledgeGap: data.isKnowledgeGap,
        retrievalStats: data.retrievalStats,
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('RAG Query Error:', err);
      const errorMessage: ChatMessage = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: `⚠️ **Connection Error**: Unable to complete vector retrieval query.\n\n*Error details: ${err.message || 'Check server connection'}*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        confidence: 'low',
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 2000);
  };

  const clearChat = () => {
    setMessages([
      {
        id: 'welcome-fresh',
        role: 'assistant',
        content: `🧹 Conversation cleared. Ready to search across internal documentation, Slack threads, and wiki knowledge silos.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedFollowUps: [
          'How do I fix Apple Silicon Docker build errors?',
          'What is the 1-year cliff vesting schedule in Carta?',
          'How do I request Teleport bastion access?',
        ]
      }
    ]);
  };

  const getConfidenceBadge = (confidence?: ChatMessage['confidence']) => {
    switch (confidence) {
      case 'high':
        return (
          <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-3 h-3" />
            <span>High Confidence Grounding</span>
          </span>
        );
      case 'medium':
        return (
          <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Sparkles className="w-3 h-3" />
            <span>Grounded Response</span>
          </span>
        );
      case 'insufficient_knowledge':
        return (
          <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-xs font-medium bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <AlertTriangle className="w-3 h-3" />
            <span>Knowledge Gap Logged</span>
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] max-w-7xl mx-auto px-2 sm:px-4 lg:px-8 py-4">
      {/* Category Filter Pills & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800 shrink-0">
        <div className="flex items-center space-x-1 overflow-x-auto py-1">
          <span className="text-xs text-slate-400 font-medium mr-1.5 flex items-center">
            <Filter className="w-3.5 h-3.5 mr-1 text-indigo-400" /> Filter:
          </span>
          {[
            { id: 'all', label: 'All Knowledge Silos' },
            { id: 'engineering', label: 'Engineering Wiki' },
            { id: 'hr_people', label: 'HR & Benefits' },
            { id: 'slack_threads', label: 'Slack Archives' },
            { id: 'security_it', label: 'Security & Access' },
            { id: 'product_wiki', label: 'RFCs & Architecture' },
            { id: 'glossary', label: 'Acronyms Glossary' },
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`text-xs px-2.5 py-1 rounded-full font-medium transition-colors whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <button
          onClick={clearChat}
          className="flex items-center space-x-1.5 text-xs text-slate-400 hover:text-slate-200 px-2.5 py-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Clear Chat</span>
        </button>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto py-4 space-y-6 pr-1">
        {/* Starter Queries if just starting */}
        {messages.length <= 1 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 my-2 animate-in fade-in">
            {STARTER_QUERIES.map((category, idx) => {
              const Icon = category.icon;
              return (
                <div 
                  key={idx} 
                  className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 hover:border-slate-700 transition-all shadow-sm"
                >
                  <div className="flex items-center space-x-2.5 mb-2.5">
                    <div className={`p-1.5 rounded-lg border bg-gradient-to-br ${category.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-semibold text-slate-200 uppercase tracking-wide">
                      {category.role}
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    {category.queries.map((q, qIdx) => (
                      <button
                        key={qIdx}
                        onClick={() => handleSend(q)}
                        className="w-full text-left text-xs text-slate-300 hover:text-indigo-300 bg-slate-800/50 hover:bg-slate-800 px-3 py-2 rounded-lg transition-all flex items-center justify-between group border border-transparent hover:border-indigo-500/20"
                      >
                        <span className="truncate mr-2 font-medium">{q}</span>
                        <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-indigo-400 shrink-0 transition-transform group-hover:translate-x-0.5" />
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Message Items */}
        {messages.map((message) => {
          const isAssistant = message.role === 'assistant';

          return (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${isAssistant ? 'justify-start' : 'justify-end'}`}
            >
              {isAssistant && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-600 flex items-center justify-center text-white shrink-0 shadow-md shadow-indigo-600/20 mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`flex flex-col max-w-3xl rounded-2xl p-4 sm:p-5 shadow-md ${
                  isAssistant
                    ? 'bg-slate-900 border border-slate-800 text-slate-100'
                    : 'bg-indigo-600 text-white shadow-indigo-600/20'
                }`}
              >
                {/* Header for Assistant Message */}
                {isAssistant && (
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-slate-800/80">
                    <div className="flex items-center space-x-2">
                      <span className="font-semibold text-xs text-white">Nexus Assistant</span>
                      {getConfidenceBadge(message.confidence)}
                    </div>

                    <div className="flex items-center space-x-2 text-xs text-slate-400">
                      {message.retrievalStats && (
                        <span className="font-mono text-slate-500 hidden sm:inline">
                          {message.retrievalStats.queryExecutionTimeMs}ms
                        </span>
                      )}
                      <button
                        onClick={() => copyToClipboard(message.content, message.id)}
                        className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
                        title="Copy text"
                      >
                        {copiedMessageId === message.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {/* Body Content with React Markdown */}
                <div className={`prose prose-invert prose-xs sm:prose-sm max-w-none break-words ${!isAssistant ? 'text-white' : ''}`}>
                  <ReactMarkdown
                    remarkPlugins={[remarkGfm]}
                    components={{
                      code({ node, className, children, ...props }) {
                        const match = /language-(\w+)/.exec(className || '');
                        return match ? (
                          <div className="relative my-2 rounded-lg bg-slate-950 p-3 font-mono text-xs text-indigo-300 border border-slate-800 overflow-x-auto">
                            <code className={className} {...props}>
                              {children}
                            </code>
                          </div>
                        ) : (
                          <code className="px-1.5 py-0.5 rounded bg-slate-800 font-mono text-xs text-indigo-300 border border-slate-700/60" {...props}>
                            {children}
                          </code>
                        );
                      },
                      p({ children }) {
                        return <p className="mb-2.5 last:mb-0 leading-relaxed">{children}</p>;
                      },
                      ul({ children }) {
                        return <ul className="list-disc list-outside pl-4 space-y-1 mb-2.5">{children}</ul>;
                      },
                      ol({ children }) {
                        return <ol className="list-decimal list-outside pl-4 space-y-1 mb-2.5">{children}</ol>;
                      },
                      blockquote({ children }) {
                        return <blockquote className="border-l-2 border-indigo-500 pl-3 my-2 italic text-slate-300">{children}</blockquote>;
                      }
                    }}
                  >
                    {message.content}
                  </ReactMarkdown>
                </div>

                {/* Grounded Source Citations */}
                {isAssistant && message.citations && message.citations.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-slate-800">
                    <div className="flex items-center space-x-1.5 text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wider">
                      <Layers className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Retrieved Knowledge Silos & Citations ({message.citations.length})</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {message.citations.map((cit, citIdx) => (
                        <button
                          key={citIdx}
                          onClick={() => setInspectCitation(cit)}
                          className="text-left bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800 hover:border-indigo-500/40 rounded-xl p-2.5 transition-all flex flex-col justify-between group cursor-pointer shadow-xs"
                        >
                          <div className="flex items-start justify-between w-full mb-1">
                            <span className="font-semibold text-xs text-slate-200 group-hover:text-indigo-300 truncate max-w-[200px]">
                              {cit.docTitle}
                            </span>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-emerald-400 shrink-0 ml-1 border border-emerald-500/20">
                              {(cit.score * 100).toFixed(0)}%
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                            <span className="capitalize text-slate-400">
                              {cit.sourceType} • {cit.channelOrUrl || 'Wiki'}
                            </span>
                            <span className="text-indigo-400 group-hover:underline text-[10px] font-medium flex items-center">
                              Inspect <ArrowRight className="w-2.5 h-2.5 ml-0.5" />
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Contact Point / Escalation Badge */}
                {isAssistant && message.contactPoint && (
                  <div className="mt-3 bg-slate-800/60 border border-slate-700/50 rounded-xl px-3 py-2 flex items-center justify-between text-xs">
                    <div className="flex items-center space-x-2 text-slate-300">
                      <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Need human escalation?</span>
                    </div>
                    <span className="font-mono text-indigo-300 font-semibold bg-slate-900 px-2 py-0.5 rounded border border-indigo-500/30">
                      {message.contactPoint}
                    </span>
                  </div>
                )}

                {/* Suggested Follow-Ups */}
                {isAssistant && message.suggestedFollowUps && message.suggestedFollowUps.length > 0 && (
                  <div className="mt-3 pt-2">
                    <span className="text-[11px] text-slate-400 font-medium block mb-1.5">
                      Suggested follow-up queries:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {message.suggestedFollowUps.map((fu, fIdx) => (
                        <button
                          key={fIdx}
                          onClick={() => handleSend(fu)}
                          className="text-xs bg-slate-800 hover:bg-indigo-600/30 text-indigo-300 hover:text-white border border-slate-700 hover:border-indigo-500/40 px-2.5 py-1 rounded-lg transition-all text-left flex items-center space-x-1"
                        >
                          <Sparkles className="w-3 h-3 text-indigo-400 shrink-0" />
                          <span className="truncate max-w-xs">{fu}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Timestamp */}
                <div className="mt-2 text-[10px] text-slate-400 self-end">
                  {message.timestamp}
                </div>
              </div>

              {!isAssistant && (
                <div className="w-8 h-8 rounded-xl bg-slate-700 flex items-center justify-center text-slate-200 shrink-0 mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex items-start space-x-3 justify-start animate-in fade-in">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-600 flex items-center justify-center text-white shrink-0 shadow-md shadow-indigo-600/20">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-slate-200 flex flex-col space-y-2 max-w-md shadow-md">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-indigo-500 animate-ping"></div>
                <span className="text-xs font-medium text-slate-300">Searching vector embeddings & company silos...</span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono">
                Querying 256-dim vector embeddings • Cosine similarity ranker • Grounded Context Synthesizer
              </p>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form Bar */}
      <div className="pt-2 border-t border-slate-800 shrink-0">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="relative flex items-center"
        >
          <input
            id="rag-query-input"
            ref={inputRef}
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder="Ask about local dev, Doppler, 401(k), Slack threads, Teleport, PTO, or RFCs..."
            disabled={isLoading}
            className="w-full bg-slate-900 border border-slate-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl px-4 py-3.5 pl-4 pr-24 text-sm text-slate-100 placeholder-slate-400 shadow-inner outline-hidden transition-all disabled:opacity-50"
          />

          <div className="absolute right-2 flex items-center space-x-1">
            <button
              id="send-rag-query-btn"
              type="submit"
              disabled={isLoading || !inputQuery.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white disabled:text-slate-500 px-3.5 py-2 rounded-lg font-medium text-xs flex items-center space-x-1.5 shadow-sm transition-all cursor-pointer disabled:cursor-not-allowed"
            >
              <span>Ask</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>

        <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 mt-1.5">
          <span>Vector RAG Grounded: strictly synthesizes facts from company docs & Slack archives</span>
          <span className="font-mono text-slate-400">256-dim Dense Vector Engine + BM25</span>
        </div>
      </div>

      {/* Citation Inspector Modal */}
      <ChunkViewerModal
        citation={inspectCitation}
        onClose={() => setInspectCitation(null)}
      />
    </div>
  );
};
