import React, { useState, useEffect } from 'react';
import { 
  CheckSquare, 
  Square, 
  Bot, 
  ExternalLink, 
  Calendar, 
  Sparkles, 
  Award, 
  ShieldCheck, 
  ArrowRight,
  Filter
} from 'lucide-react';
import { OnboardingTask } from '../types';

interface OnboardingChecklistProps {
  onAskAI: (prompt: string) => void;
}

export const OnboardingChecklist: React.FC<OnboardingChecklistProps> = ({ onAskAI }) => {
  const [tasks, setTasks] = useState<OnboardingTask[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'day_1' | 'week_1' | 'month_1'>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/onboarding/tasks');
      if (res.ok) {
        const data = await res.json();
        // Check local storage for completed states
        const savedCompleted = localStorage.getItem('nexus_onboarding_completed');
        if (savedCompleted) {
          try {
            const completedMap = JSON.parse(savedCompleted);
            const merged = data.map((t: OnboardingTask) => ({
              ...t,
              completed: completedMap[t.id] !== undefined ? completedMap[t.id] : t.completed,
            }));
            setTasks(merged);
            return;
          } catch (e) {
            console.error(e);
          }
        }
        setTasks(data);
      }
    } catch (err) {
      console.error('Failed to fetch tasks:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleTask = (taskId: string) => {
    setTasks(prev => {
      const updated = prev.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t);
      // save to local storage
      const completedMap: Record<string, boolean> = {};
      updated.forEach(t => { completedMap[t.id] = t.completed; });
      localStorage.setItem('nexus_onboarding_completed', JSON.stringify(completedMap));
      return updated;
    });
  };

  const filteredTasks = tasks.filter(t => {
    const matchesCategory = selectedCategory === 'all' || t.category === selectedCategory;
    const matchesDept = departmentFilter === 'All' || t.department === 'All' || t.department === departmentFilter;
    return matchesCategory && matchesDept;
  });

  const totalCompleted = tasks.filter(t => t.completed).length;
  const progressPercent = tasks.length > 0 ? Math.round((totalCompleted / tasks.length) * 100) : 0;

  const getCategoryTitle = (cat: 'day_1' | 'week_1' | 'month_1') => {
    switch (cat) {
      case 'day_1': return 'Day 1: Access, Credentials & Identity';
      case 'week_1': return 'Week 1: Tooling, Repos & Local Setup';
      case 'month_1': return 'Month 1: Production PRs, SLAs & Ownership';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header & Progress Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center space-x-2 text-indigo-400 text-xs font-semibold uppercase tracking-wider mb-1">
              <Calendar className="w-4 h-4" />
              <span>New Hire 30-60-90 Milestone Roadmap</span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              Enterprise Onboarding Checklist
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Complete these critical security, environment, and HR milestones. Click &quot;Ask Nexus&quot; on any item to receive step-by-step guidance grounded in company docs.
            </p>
          </div>

          {/* Progress Tracker Widget */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 min-w-[240px] flex flex-col justify-center">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium">Onboarding Progress</span>
              <span className="text-xs font-bold text-indigo-300 font-mono">
                {totalCompleted} of {tasks.length} ({progressPercent}%)
              </span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full rounded-full transition-all duration-500 ease-out"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
            {progressPercent === 100 && (
              <div className="flex items-center space-x-1 text-emerald-400 text-xs font-medium mt-2">
                <Award className="w-3.5 h-3.5" />
                <span>All onboarding tasks completed! 🎉</span>
              </div>
            )}
          </div>
        </div>

        {/* Filters Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 mt-6 pt-4 border-t border-slate-800/80">
          <div className="flex items-center space-x-1.5 overflow-x-auto">
            <span className="text-xs text-slate-400 font-medium mr-1 flex items-center">
              <Filter className="w-3.5 h-3.5 mr-1 text-indigo-400" /> Timeline:
            </span>
            {[
              { id: 'all', label: 'All Milestones' },
              { id: 'day_1', label: 'Day 1' },
              { id: 'week_1', label: 'Week 1' },
              { id: 'month_1', label: 'Month 1' },
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as any)}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Department:</span>
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-hidden focus:border-indigo-500"
            >
              <option value="All">All Departments</option>
              <option value="Engineering">Engineering</option>
              <option value="Product">Product</option>
              <option value="Operations">Operations</option>
            </select>
          </div>
        </div>
      </div>

      {/* Task Groups */}
      {loading ? (
        <div className="p-8 text-center text-slate-400">Loading checklist roadmap...</div>
      ) : (
        <div className="space-y-6">
          {(['day_1', 'week_1', 'month_1'] as const).map(catKey => {
            const groupTasks = filteredTasks.filter(t => t.category === catKey);
            if (groupTasks.length === 0) return null;

            return (
              <div key={catKey} className="space-y-3">
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                  <h3 className="font-semibold text-slate-200 text-sm tracking-wide uppercase">
                    {getCategoryTitle(catKey)}
                  </h3>
                  <span className="text-xs text-slate-500 font-mono">
                    ({groupTasks.filter(t => t.completed).length}/{groupTasks.length} done)
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  {groupTasks.map((task) => (
                    <div
                      key={task.id}
                      className={`bg-slate-900 border rounded-xl p-4 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                        task.completed
                          ? 'border-emerald-500/30 bg-emerald-950/10'
                          : 'border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {/* Checkbox and Task Details */}
                      <div className="flex items-start space-x-3.5">
                        <button
                          onClick={() => toggleTask(task.id)}
                          className="mt-0.5 text-slate-400 hover:text-indigo-400 focus:outline-hidden transition-colors"
                        >
                          {task.completed ? (
                            <CheckSquare className="w-5 h-5 text-emerald-400" />
                          ) : (
                            <Square className="w-5 h-5 text-slate-500" />
                          )}
                        </button>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className={`font-semibold text-sm ${task.completed ? 'line-through text-slate-400' : 'text-white'}`}>
                              {task.title}
                            </span>
                            <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                              {task.department}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-1 leading-normal">
                            {task.description}
                          </p>
                        </div>
                      </div>

                      {/* Ask AI Action Button */}
                      <div className="flex items-center space-x-2 shrink-0 self-end sm:self-center">
                        <button
                          onClick={() => onAskAI(task.queryPrompt)}
                          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 text-xs font-medium transition-all shadow-xs group"
                        >
                          <Bot className="w-3.5 h-3.5" />
                          <span>Ask Nexus</span>
                          <ArrowRight className="w-3 h-3 text-indigo-400 group-hover:text-white transition-transform group-hover:translate-x-0.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
