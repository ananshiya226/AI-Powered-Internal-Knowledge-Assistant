import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { KnowledgeDocument, SourceCategory } from './src/types.js';
import { processRAGQuery, recordedKnowledgeGaps, totalQueriesProcessedCount, getAverageRetrievalTimeMs } from './server/ragService.js';
import { vectorStore } from './server/vectorStore.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Initialize vector store on boot
  vectorStore.initialize();

  // API Routes
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'Nexus Enterprise RAG Assistant',
      timestamp: new Date().toISOString(),
      documentsIndexed: vectorStore.getDocuments().length,
      chunksIndexed: vectorStore.getChunks().length,
    });
  });

  // 1. Core RAG Query Endpoint
  app.post('/api/rag/query', async (req: Request, res: Response) => {
    try {
      const { query, categoryFilter } = req.body;
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ error: 'Query string is required' });
      }

      const response = await processRAGQuery(
        query.trim(),
        categoryFilter as SourceCategory | 'all' | undefined
      );

      res.json(response);
    } catch (err: any) {
      console.error('[API /api/rag/query] Error:', err);
      res.status(500).json({ error: 'Failed to process RAG query', details: err.message });
    }
  });

  // 2. Raw Vector Retrieval / Semantic Search Playground
  app.post('/api/rag/search', async (req: Request, res: Response) => {
    try {
      const { query, topK = 5, categoryFilter } = req.body;
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ error: 'Query string is required' });
      }

      const results = await vectorStore.search(
        query.trim(),
        Number(topK) || 5,
        categoryFilter as SourceCategory | 'all' | undefined
      );

      res.json({
        query,
        topK: Number(topK) || 5,
        resultsCount: results.length,
        results,
      });
    } catch (err: any) {
      console.error('[API /api/rag/search] Error:', err);
      res.status(500).json({ error: 'Vector search failed', details: err.message });
    }
  });

  // 3. Document Management Endpoints
  app.get('/api/docs', (req: Request, res: Response) => {
    const docs = vectorStore.getDocuments();
    res.json(docs);
  });

  app.get('/api/docs/:id', (req: Request, res: Response) => {
    const doc = vectorStore.getDocumentById(req.params.id);
    if (!doc) {
      return res.status(404).json({ error: 'Document not found' });
    }
    const chunks = vectorStore.getChunks().filter(c => c.docId === doc.id);
    res.json({
      ...doc,
      chunks,
    });
  });

  app.post('/api/docs', async (req: Request, res: Response) => {
    try {
      const { title, category, sourceType, department, content, channelOrUrl, tags, author } = req.body;
      if (!title || !content || !category) {
        return res.status(400).json({ error: 'title, category, and content are required' });
      }

      const newDoc: KnowledgeDocument = {
        id: `doc-${Date.now()}`,
        title: title.trim(),
        category: category as SourceCategory,
        sourceType: sourceType || 'wiki',
        department: department || 'Engineering',
        content: content.trim(),
        author: author || 'New Hire Contributor',
        lastUpdated: new Date().toISOString().split('T')[0],
        channelOrUrl: channelOrUrl || '',
        tags: Array.isArray(tags) ? tags : (tags ? tags.split(',').map((t: string) => t.trim()) : ['user-upload']),
      };

      const added = vectorStore.addDocument(newDoc);
      res.status(201).json(added);
    } catch (err: any) {
      console.error('[API POST /api/docs] Error:', err);
      res.status(500).json({ error: 'Failed to ingest document', details: err.message });
    }
  });

  app.delete('/api/docs/:id', (req: Request, res: Response) => {
    const deleted = vectorStore.deleteDocument(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: 'Document not found or already deleted' });
    }
    res.json({ success: true, deletedDocId: req.params.id });
  });

  // 4. Analytics & Knowledge Gaps
  app.get('/api/analytics/stats', (req: Request, res: Response) => {
    const docs = vectorStore.getDocuments();
    const chunks = vectorStore.getChunks();

    const categoriesCount: Record<SourceCategory, number> = {
      engineering: 0,
      hr_people: 0,
      slack_threads: 0,
      security_it: 0,
      product_wiki: 0,
      glossary: 0,
    };

    for (const doc of docs) {
      if (categoriesCount[doc.category] !== undefined) {
        categoriesCount[doc.category]++;
      }
    }

    res.json({
      totalDocuments: docs.length,
      totalChunks: chunks.length,
      categoriesCount,
      totalQueriesProcessed: totalQueriesProcessedCount,
      knowledgeGapsIdentified: recordedKnowledgeGaps.length,
      averageRetrievalTimeMs: getAverageRetrievalTimeMs(),
    });
  });

  app.get('/api/analytics/gaps', (req: Request, res: Response) => {
    res.json(recordedKnowledgeGaps);
  });

  app.patch('/api/analytics/gaps/:id', (req: Request, res: Response) => {
    const gap = recordedKnowledgeGaps.find(g => g.id === req.params.id);
    if (!gap) {
      return res.status(404).json({ error: 'Gap item not found' });
    }
    if (req.body.status) {
      gap.status = req.body.status;
    }
    res.json(gap);
  });

  // 5. Onboarding Task Checklist
  app.get('/api/onboarding/tasks', (req: Request, res: Response) => {
    const tasks = [
      {
        id: 'task-1',
        category: 'day_1',
        title: 'Configure Okta SSO & YubiKey/Verify MFA',
        description: 'Complete 2-factor authentication setup and verify access to email and Slack.',
        completed: true,
        department: 'All',
        queryPrompt: 'How do I set up Okta MFA and 1Password vault on Day 1?',
        relatedDocId: 'doc-sec-001',
      },
      {
        id: 'task-2',
        category: 'day_1',
        title: 'Claim 1Password Enterprise Invite & Team Vaults',
        description: 'Set up password manager master key and join your squad shared vault.',
        completed: true,
        department: 'All',
        queryPrompt: 'Where are the 1Password shared team vaults and how to join?',
        relatedDocId: 'doc-sec-001',
      },
      {
        id: 'task-3',
        category: 'day_1',
        title: 'Enroll in Fidelity 401(k) Matching (5% Match)',
        description: 'Sign in to NetBenefits and set contribution to at least 6% to capture full company match.',
        completed: false,
        department: 'All',
        queryPrompt: 'How do I enroll in Fidelity 401(k) and what is the company match formula?',
        relatedDocId: 'doc-hr-001',
      },
      {
        id: 'task-4',
        category: 'week_1',
        title: 'Set up Doppler Secret Management & Local Services',
        description: 'Install Doppler CLI, authenticate with Okta, and run local microservices.',
        completed: false,
        department: 'Engineering',
        queryPrompt: 'How do I configure Doppler secrets and run make docker-up locally?',
        relatedDocId: 'doc-eng-001',
      },
      {
        id: 'task-5',
        category: 'week_1',
        title: 'Fix Docker Apple Silicon / ARM64 build settings',
        description: 'Ensure Rosetta emulation is active in Docker Desktop if on M1/M2/M3 Mac.',
        completed: false,
        department: 'Engineering',
        queryPrompt: 'How do I fix Apple Silicon exec format errors in Docker?',
        relatedDocId: 'doc-slack-001',
      },
      {
        id: 'task-6',
        category: 'week_1',
        title: 'Submit Home Office $750 & Wellness $100 Stipends',
        description: 'Upload monitor/desk receipts to Brex under L&D / Home Office category.',
        completed: false,
        department: 'All',
        queryPrompt: 'How do I submit home office and wellness expenses in Brex?',
        relatedDocId: 'doc-hr-002',
      },
      {
        id: 'task-7',
        category: 'month_1',
        title: 'Merge First Pull Request via ArgoCD Staging Preview',
        description: 'Open a feature branch adhering to feat/PROJ-1234 naming and get 2 peer reviews.',
        completed: false,
        department: 'Engineering',
        queryPrompt: 'What are the PR review SLAs and staging preview deploy rules?',
        relatedDocId: 'doc-eng-002',
      },
      {
        id: 'task-8',
        category: 'month_1',
        title: 'Request Teleport Staging Cluster Access in Slack',
        description: 'Install tsh CLI and submit elevated access request in #it-access-requests.',
        completed: false,
        department: 'Engineering',
        queryPrompt: 'How do I connect to staging Kubernetes clusters via Teleport tsh?',
        relatedDocId: 'doc-sec-001',
      },
    ];

    res.json(tasks);
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Nexus Server] Knowledge Assistant running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
