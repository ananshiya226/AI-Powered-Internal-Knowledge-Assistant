# Internal Knowledge Assistant using RAG & Gemini

An enterprise onboarding and technical knowledge retrieval system powered by **Google Gemini**, **Retrieval-Augmented Generation (RAG)**, dense semantic vector embeddings, and hybrid context synthesis.

[![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-3178C6?logo=typescript&logoColor=white)](#)
[![React](https://img.shields.io/badge/React-18-61DAFB?logo=react&logoColor=black)](#)
[![Google Gemini](https://img.shields.io/badge/Google%20Gemini-LLM%20%26%20Embeddings-8E75B2?logo=google&logoColor=white)](#)
[![Node.js](https://img.shields.io/badge/Node.js-Express-339933?logo=node.js&logoColor=white)](#)
[![FastAPI](https://img.shields.io/badge/Python-FastAPI-009688?logo=fastapi&logoColor=white)](#)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-CSS-38B2AC?logo=tailwind-css&logoColor=white)](#)

> **Tech Stack**: React • TypeScript • Node.js • Express • Python • FastAPI • Google Gemini • RAG • Vector Search

---

## 📌 Problem Statement

In modern engineering organizations, critical knowledge is fragmented across disparate silos:
- **Engineering wikis** (local environment setup, Docker configuration, service architectures)
- **RFC proposals** (microservice event models, CI/CD staging pipelines)
- **Security runbooks** (Okta SSO, 1Password vaults, Teleport bastion clusters, temporary AWS IAM escalation)
- **HR & People policies** (401k matching formulas, equity vesting cliffs, health insurance, L&D stipends)
- **Slack thread archives** (undocumented edge cases like Apple Silicon M1/M2 Docker build fixes and database sanitization scripts)

New hires spend days navigating outdated docs or interrupting senior engineers. **Internal Knowledge Assistant** bridges this gap by indexing multi-silo internal documents into a unified vector retrieval pipeline that provides instant, grounded answers via **Google Gemini** with verifiable source citations and automatic knowledge-gap escalation.

> **⚠️ Synthetic Data Disclaimer**: All company names, employee names, credentials, policies, URLs, and internal documents used in this project are synthetic/demo data created strictly for educational and portfolio purposes.

---

## 🏗️ Architecture & RAG Pipeline

```
                                  ┌───────────────────────────┐
                                  │    React + TypeScript     │
                                  │   Interactive Dashboard   │
                                  └─────────────┬─────────────┘
                                                │ REST API
                                                ▼
                                  ┌───────────────────────────┐
                                  │     Python + FastAPI      │
                                  │     (Primary Backend)     │
                                  └─────────────┬─────────────┘
                                                │
                 ┌──────────────────────────────┼──────────────────────────────┐
                 ▼                              ▼                              ▼
      ┌─────────────────────┐        ┌─────────────────────┐        ┌─────────────────────┐
      │  Document Ingestion │        │    Hybrid Search    │        │  Google Gemini LLM  │
      │  & Smart Chunking   │        │ Vector + BM25 Rank  │        │  / Embeddings API   │
      └──────────┬──────────┘        └──────────┬──────────┘        └──────────┬──────────┘
                 │                              │                              │
                 └──────────────────────────────┼──────────────────────────────┘
                                                ▼
                                     ┌─────────────────────┐
                                     │ Confidence Checker  │
                                     └─────┬─────────┬─────┘
                 Score >= 0.28             │         │ Score < 0.28
              ┌────────────────────────────┘         └────────────────────────────┐
              ▼                                                                   ▼
   ┌─────────────────────┐                                             ┌─────────────────────┐
   │ Grounded Answer with│                                             │ Knowledge Gap Log   │
   │ Citations & CLI run │                                             │ & Support Escalation│
   └─────────────────────┘                                             └─────────────────────┘

                                ┌─────────────────────────────┐
                                │ Node.js + Express + TS      │
                                │ (Parallel Reference Backend)│
                                └─────────────────────────────┘
```

#### Dual Backend Implementations
- **Python + FastAPI Backend** (`/backend_python/`): Standalone Python service utilizing **Sentence Transformers (`all-MiniLM-L6-v2`)** for 384-dimensional dense semantic embeddings, **FAISS** (`IndexFlatIP`) for vector similarity search, **BM25Okapi** for sparse lexical ranking, and **Ollama** (`llama3.2`/`mistral`) for fully local grounded answer synthesis.
- **Node.js + Express + TypeScript Backend** (`/server.ts`): Full-stack web server integrating Google Gemini and fast vector retrieval with unified Vite middleware.

#### Step-by-Step RAG Pipeline Execution Flow
1. **Document Ingestion**: Markdown wikis, HR policies, and internal communication archives are ingested and split into semantically coherent chunks by header and paragraph.
2. **Dense Vector Indexing**: Chunks are embedded into dense semantic representations using **Sentence Transformers (`all-MiniLM-L6-v2`)** / Google Gemini embeddings and indexed in **FAISS** alongside **BM25 Okapi** term frequency matrices.
3. **Hybrid Search Execution**: When a user queries, the engine computes dense vector cosine similarity (60%) and BM25 token matching (40%) to retrieve the top-4 relevant chunks.
4. **Confidence Verification**: If similarity score $\ge 0.28$, context is forwarded to the LLM. If $< 0.28$, it is flagged as an unanswered Knowledge Gap with recommended escalation contacts.
5. **Grounded Answer Synthesis**: The language model (Ollama local LLM or Google Gemini) processes the retrieved context and generates a structured response with source citations, code snippets, and action steps.

---

## ✨ Key Features

1. **Grounded AI Assistant with Google Gemini & Inline Citations**:
   - Synthesizes authoritative answers using Gemini (`gemini-2.5-flash`) strictly grounded in retrieved document chunks and Slack archives.
   - Outputs full source attribution (document title, department, category, channel/URL, and relevance score).
   - Automatically extracts executable CLI steps (e.g. Docker flags, Doppler commands, teleport SSH) into dedicated action cards.

2. **Hybrid Semantic + Lexical Retrieval**:
   - Blends **Gemini vector embeddings** (`text-embedding-004`) and 256-dimensional dense projections with **BM25 token density matching** (`Score = 0.60 * Vector + 0.40 * Keyword + TitleBoost`).
   - Ensures high recall on semantic inquiries while preserving strict exact-match accuracy on technical identifiers, acronyms, and CLI commands.

3. **Autonomous Knowledge-Gap Detection**:
   - Queries with retrieval confidence below the threshold (`< 0.28`) trigger automated gap logging.
   - Escalates blocked users to the correct department Slack channel or on-call lead.
   - Surfaces unaddressed onboarding questions in the **Knowledge Gaps Dashboard** for documentation maintainers.

4. **Multi-Silo Document Explorer & Live Ingestion**:
   - Browse company knowledge across 6 categories: Engineering, HR/People, Security/IT, Slack Threads, Product RFCs, and Glossary.
   - Ingest new Markdown runbooks or delete deprecated docs with live vector re-indexing.

5. **Interactive Vector Search Playground**:
   - Inspect vector chunking, token counts, and mathematical cosine scores across all candidate chunks in real time.

6. **Dual Backend Implementation**:
   - **Primary Web Stack**: Node.js + Express + TypeScript with unified Vite middleware.
   - **Modular Python Port**: Standalone FastAPI + Pydantic + NumPy + Google GenAI service located in `/backend_python/`.

---

## 🛠️ Technology Stack

| Domain | Technologies |
|---|---|
| **AI & LLM** | Google Gemini (`gemini-2.5-flash`), Gemini Embeddings (`text-embedding-004`), `@google/genai` SDK |
| **Frontend** | React 18, TypeScript, Vite, Tailwind CSS, Lucide React |
| **Primary Backend** | Node.js, Express, TypeScript, tsx |
| **Python Backend** | Python 3.10+, FastAPI, Uvicorn, Pydantic v2, NumPy, `google-genai` |
| **RAG & Retrieval** | Dense Semantic Vector Projections, Cosine Similarity, BM25 Lexical Ranker |
| **Styling & UI** | Tailwind CSS with custom high-contrast dark theme, Responsive mobile/desktop layouts |

---

## 🚀 Quick Start Guide

### Prerequisites
- Node.js v18+ or v20+ LTS
- npm or bun

### 1. Running the Full-Stack Application (Node.js + React)

```bash
# 1. Install dependencies
npm install

# 2. Start the development server (Express + React on port 3000)
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

### 2. Running the Python FastAPI Backend (Optional / Modular)

A complete Python FastAPI implementation is provided in `/backend_python/`:

```bash
# 1. Navigate to the Python backend directory
cd backend_python

# 2. Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install requirements
pip install -r requirements.txt

# 4. Start the FastAPI server
uvicorn main:app --reload --port 8000
```

- **Interactive Swagger Documentation**: `http://localhost:8000/docs`
- **Health Check**: `http://localhost:8000/api/health`

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Service health, indexed document and chunk counts |
| `POST` | `/api/rag/query` | Executes RAG retrieval, context grounding, and citation generation |
| `POST` | `/api/rag/search` | Raw vector search returning top-K chunks with similarity scores |
| `GET` | `/api/docs` | Retrieves all indexed knowledge documents |
| `GET` | `/api/docs/:id` | Retrieves a specific document and its constituent chunks |
| `POST` | `/api/docs` | Ingests a new document and computes vector embeddings |
| `DELETE` | `/api/docs/:id` | Deletes a document and purges its chunks from the vector store |
| `GET` | `/api/analytics/stats` | Dynamic metrics (query counts, latencies, category distribution) |
| `GET` | `/api/analytics/gaps` | List of unaddressed queries / documentation gaps |
| `PATCH` | `/api/analytics/gaps/:id` | Update status of a knowledge gap item (`open`, `in_review`, `resolved`) |
| `GET` | `/api/onboarding/tasks` | Checklist tasks with smart RAG query prompt bindings |

---

## 🔬 How Hybrid Retrieval Works

Traditional pure vector search can struggle with exact acronyms (e.g. `DRP`, `CAP`, `FTO`) or CLI flags (e.g. `linux/amd64`, `doppler setup`). Pure keyword search fails on semantic paraphrasing (e.g. asking *"How much 401k does company match?"* vs. doc titled *"Total Rewards: Retirement Plan"*).

Our hybrid ranking formula combines both:

$$\text{Combined Score} = (0.60 \times \text{Cosine Similarity}) + (0.40 \times \text{BM25 Keyword Density}) + \text{Title Boost}$$

1. **Dense Vector Similarity**: Measures angle between the 256-dimensional query vector and chunk vector.
2. **Lexical Keyword Match**: Evaluates token frequency and exact term overlap across title and body.
3. **Threshold Filter**: If the top score is below `0.28`, the query is flagged as an unanswered knowledge gap.

---

## 🚧 Current Limitations & Future Roadmap

### Current Scope
- **Vector Storage**: Current implementation uses an in-memory vector index with cosine similarity for demonstration and rapid prototyping. Production target: **PostgreSQL with `pgvector`** or a dedicated vector database such as **ChromaDB / Pinecone**.
- **Embeddings**: Integrates **Google Gemini Embeddings (`text-embedding-004`)** when an API key is present, with deterministic dense vector projection fallback for offline demo portability.
- **Dataset**: Pre-seeded with realistic technical runbooks, HR policies, and internal communication archives.

### Architecture Roadmap
- [ ] **Authentication & RBAC**: Implement JWT-based authentication and role-based access control (RBAC) to restrict knowledge retrieval based on user roles and departments (e.g., filtering sensitive HR or infra records at the retrieval stage).
- [ ] **Persistent Vector Database**: Migration to PostgreSQL with `pgvector` or ChromaDB for multi-instance scaling and persistence.
- [ ] **Asynchronous Ingestion Pipeline**: Celery / Redis background worker for parsing uploaded PDFs, Markdown repositories, and Confluence webhooks.
- [ ] **Automated RAG Evaluation**: Integration with RAGAS / TruLens metrics for context recall, precision, and answer faithfulness.

---

## 📄 License

MIT License. Designed and built as a portfolio and educational demonstration of enterprise RAG architectures.
