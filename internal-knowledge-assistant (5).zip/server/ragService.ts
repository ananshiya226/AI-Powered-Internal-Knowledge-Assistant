import { GoogleGenAI } from '@google/genai';
import { AssistantResponse, GroundedCitation, KnowledgeGapItem, SearchResult, SourceCategory } from '../src/types.js';
import { vectorStore } from './vectorStore.js';

let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY') {
    try {
      geminiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (e) {
      console.warn('[Gemini] Failed to initialize GoogleGenAI client:', e);
    }
  }
  return geminiClient;
}

// In-memory knowledge gaps and query tracking
export const recordedKnowledgeGaps: KnowledgeGapItem[] = [
  {
    id: 'gap-001',
    query: 'How do I set up my corporate Uber for Business account for late-night rides?',
    timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
    category: 'hr_people',
    status: 'open',
    suggestedDocTitle: 'Travel & Commuter Benefits Policy',
    frequency: 3,
  },
  {
    id: 'gap-002',
    query: 'What is the deployment procedure for the legacy Ruby billing worker?',
    timestamp: new Date(Date.now() - 86400000 * 1).toISOString(),
    category: 'engineering',
    status: 'in_review',
    suggestedDocTitle: 'Legacy Billing Service Maintenance & Deprecation Runbook',
    frequency: 2,
  },
];

export const queryExecutionTimes: number[] = [14, 18, 22, 19];
export let totalQueriesProcessedCount = 4;

export function getAverageRetrievalTimeMs(): number {
  if (queryExecutionTimes.length === 0) return 0;
  const sum = queryExecutionTimes.reduce((acc, val) => acc + val, 0);
  return Math.round(sum / queryExecutionTimes.length);
}

export async function processRAGQuery(
  query: string,
  categoryFilter?: SourceCategory | 'all'
): Promise<AssistantResponse> {
  const startTime = Date.now();
  totalQueriesProcessedCount++;

  // 1. Retrieve top-4 most relevant chunks from Vector Store
  const topK = 4;
  const searchResults: SearchResult[] = await vectorStore.search(query, topK, categoryFilter);
  const executionTimeMs = Math.max(1, Date.now() - startTime);
  queryExecutionTimes.push(executionTimeMs);
  if (queryExecutionTimes.length > 50) {
    queryExecutionTimes.shift();
  }

  const totalChunks = vectorStore.getChunks().length;
  const highestScore = searchResults.length > 0 ? searchResults[0].score : 0;

  // Format citations for UI
  const citations: GroundedCitation[] = searchResults.map(r => ({
    chunkId: r.chunk.id,
    docId: r.chunk.docId,
    docTitle: r.chunk.docTitle,
    category: r.chunk.category,
    sourceType: r.chunk.sourceType,
    channelOrUrl: r.chunk.channelOrUrl,
    snippet: r.chunk.text.substring(0, 280) + '...',
    score: r.score,
  }));

  // Determine if this is an insufficient knowledge / knowledge gap case
  const isLowConfidence = highestScore < 0.28 || searchResults.length === 0;

  // If low confidence or gap detected
  if (isLowConfidence) {
    const existingGap = recordedKnowledgeGaps.find(g => g.query.toLowerCase() === query.toLowerCase());
    if (existingGap) {
      existingGap.frequency += 1;
    } else {
      recordedKnowledgeGaps.unshift({
        id: `gap-${Date.now()}`,
        query,
        timestamp: new Date().toISOString(),
        category: categoryFilter && categoryFilter !== 'all' ? categoryFilter : 'engineering',
        status: 'open',
        suggestedDocTitle: `Documentation Request: ${query.slice(0, 50)}...`,
        frequency: 1,
      });
    }

    return {
      answer: `I could not locate an authoritative answer for **"${query}"** in our internal knowledge base (Confluence wiki, HR policies, or indexed Slack archives).\n\n### 🔍 Recommended Escalation Steps:\n- **Engineering & Tooling**: Ask in Slack channel \`#eng-support\` or tag \`@platform-help\`.\n- **IT & Access Requests**: Submit a ticket in \`#it-access-requests\` or check Okta dashboard.\n- **HR & Benefits**: Contact the People team in \`#ask-people-ops\` or email \`people@acme.co\`.\n\n*Note: This query has been automatically logged in our **Knowledge Gaps Dashboard** so the documentation maintainers can author a new wiki guide.*`,
      citations: [],
      confidence: 'insufficient_knowledge',
      suggestedFollowUps: [
        'How do I request software access in #it-access-requests?',
        'Who is on-call for platform engineering?',
        'How do I contribute a new guide to the internal wiki?',
      ],
      actionSteps: [
        'Post question to the relevant department Slack channel',
        'Tag your team onboarding buddy or engineering manager',
        'Check back once documentation team updates the knowledge silo',
      ],
      contactPoint: '#eng-support or #ask-people-ops',
      isKnowledgeGap: true,
      retrievalStats: {
        totalChunksIndexed: totalChunks,
        searchedChunks: totalChunks,
        topMatchesCount: 0,
        queryExecutionTimeMs: executionTimeMs,
        embeddingModel: '256-dim Dense Vector Engine + BM25 Ranker',
      },
    };
  }

  // 2. Synthesize structured grounded answer from retrieved context
  return await generateSynthesizedGroundedResponse(query, searchResults, citations, totalChunks, executionTimeMs);
}

async function generateSynthesizedGroundedResponse(
  query: string,
  searchResults: SearchResult[],
  citations: GroundedCitation[],
  totalChunks: number,
  executionTimeMs: number
): Promise<AssistantResponse> {
  const topResult = searchResults[0];
  const primaryDoc = topResult.chunk;

  // Extract clean context body
  const cleanBody = primaryDoc.text.replace(/^\[Document:[^\]]+\]\n/, '').trim();

  let formattedAnswer = `### Grounded Resolution from **${primaryDoc.docTitle}**\n` +
    `*Source: ${primaryDoc.sourceType.toUpperCase()} • ${primaryDoc.channelOrUrl || 'Internal Wiki'} (${primaryDoc.department})*\n\n` +
    `${cleanBody}`;

  // If there's a strong secondary source chunk from a different doc or section
  if (searchResults.length > 1 && searchResults[1].score > 0.35) {
    const secondaryDoc = searchResults[1].chunk;
    if (secondaryDoc.docId !== primaryDoc.docId || secondaryDoc.chunkIndex !== primaryDoc.chunkIndex) {
      const secClean = secondaryDoc.text.replace(/^\[Document:[^\]]+\]\n/, '').trim();
      formattedAnswer += `\n\n---\n\n### 📌 Related Cross-Silo Context: **${secondaryDoc.docTitle}**\n` +
        `*Source: ${secondaryDoc.sourceType.toUpperCase()} • ${secondaryDoc.channelOrUrl || 'Internal'}*\n\n` +
        `${secClean.slice(0, 450)}${secClean.length > 450 ? '...' : ''}`;
    }
  }

  // Attempt live Google Gemini LLM synthesis if API key is active
  const ai = getGeminiClient();
  if (ai) {
    try {
      const contextText = searchResults
        .map((r, idx) => `[Source ${idx + 1}: ${r.chunk.docTitle} (${r.chunk.category})]\n${r.chunk.text}`)
        .join('\n\n---\n\n');

      const geminiPrompt = `You are the Acme Internal Onboarding Knowledge Assistant.
Answer the following employee query by grounding your answer STRICTLY in the provided internal company knowledge chunks.

Employee Question: "${query}"

Retrieved Knowledge Chunks:
${contextText}

Guidelines:
- Start with a clear, direct resolution citing the relevant doc.
- Format key runbook commands or config parameters with markdown code blocks.
- Highlight any required escalation channels or prerequisites.
- Keep the tone helpful, precise, and professional.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: geminiPrompt,
      });

      if (response && response.text) {
        formattedAnswer = response.text;
      }
    } catch (err) {
      console.warn('[Gemini] Model synthesis failed, falling back to grounded chunk synthesizer:', err);
    }
  }

  const followUps = generateSmartFollowUps(query, searchResults);
  const actionSteps = extractActionSteps(formattedAnswer);
  const contactPoint = extractContactPoint(searchResults);

  return {
    answer: formattedAnswer,
    citations,
    confidence: topResult.score > 0.5 ? 'high' : 'medium',
    suggestedFollowUps: followUps,
    actionSteps,
    contactPoint,
    isKnowledgeGap: false,
    retrievalStats: {
      totalChunksIndexed: totalChunks,
      searchedChunks: totalChunks,
      topMatchesCount: searchResults.length,
      queryExecutionTimeMs: executionTimeMs,
      embeddingModel: ai ? 'Google Gemini Embeddings (text-embedding-004) + BM25' : '256-dim Dense Vector Engine + BM25 Ranker',
    },
  };
}

function generateSmartFollowUps(query: string, results: SearchResult[]): string[] {
  const q = query.toLowerCase();
  if (q.includes('docker') || q.includes('silicon') || q.includes('m1') || q.includes('m2') || q.includes('local')) {
    return [
      'How do I configure Doppler secrets for local services?',
      'How can I seed my local Postgres with sanitized staging data?',
      'What are the branch naming rules for git PRs?',
    ];
  }
  if (q.includes('401k') || q.includes('fidelity') || q.includes('match') || q.includes('retirement')) {
    return [
      'What is the 1-year cliff and vesting schedule for equity in Carta?',
      'How do I claim my $1,500 annual L&D stipend in Brex?',
      'How much does Acme contribute to the HSA health plan?',
    ];
  }
  if (q.includes('doppler') || q.includes('secret') || q.includes('env')) {
    return [
      'How do I run microservices with doppler run -- make dev?',
      'Where do I request access to Doppler production configs?',
      'How do I resolve Docker Apple Silicon build issues?',
    ];
  }
  if (q.includes('teleport') || q.includes('tsh') || q.includes('bastion') || q.includes('aws') || q.includes('iam')) {
    return [
      'How do I request temporary 4-hour elevated AWS access in Slack?',
      'Where do I find my squad 1Password vault for API tokens?',
      'How do I connect to staging Kubernetes clusters?',
    ];
  }
  if (q.includes('stipend') || q.includes('brex') || q.includes('expense') || q.includes('learning')) {
    return [
      'What is the submission deadline for monthly Brex receipts?',
      'What are the 11 company paid holidays and FTO rules?',
      'How do I view my equity grants in Carta?',
    ];
  }
  if (q.includes('rfc') || q.includes('kafka') || q.includes('architecture') || q.includes('cap')) {
    return [
      'What is the architectural SLA for payment event processing?',
      'What does internal acronym DRP and SLO stand for?',
      'How do I submit an RFC to the Architecture Review Board?',
    ];
  }

  return [
    'How do I configure Doppler secrets for local microservices?',
    'What is our 401(k) company match in Fidelity?',
    'How do I request elevated AWS permissions in Slack?',
  ];
}

function extractActionSteps(text: string): string[] {
  const steps: string[] = [];
  const lines = text.split('\n');
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (/^(\d+\.|\*|-)\s+`?[a-zA-Z0-9]/.test(trimmed) && trimmed.length > 10 && trimmed.length < 140) {
      const cleaned = trimmed.replace(/^(\d+\.|\*|-)\s+/, '').replace(/\*\*/g, '');
      if (cleaned.toLowerCase().startsWith('step') || cleaned.toLowerCase().startsWith('run') || cleaned.toLowerCase().startsWith('verify') || cleaned.toLowerCase().startsWith('install') || cleaned.toLowerCase().startsWith('login') || cleaned.toLowerCase().startsWith('submit') || cleaned.toLowerCase().startsWith('execute') || cleaned.toLowerCase().startsWith('export')) {
        steps.push(cleaned);
      }
    }
  }

  if (steps.length > 0) {
    return steps.slice(0, 4);
  }

  return [
    'Review referenced runbook or wiki doc',
    'Execute specified CLI commands or policy steps',
    'Reach out to indicated escalation contact if blocked',
  ];
}

function extractContactPoint(results: SearchResult[]): string {
  if (results.length === 0) return '#eng-support or #ask-people-ops';

  const doc = results[0].chunk;
  if (doc.category === 'engineering') return '#eng-support or #dev-environment';
  if (doc.category === 'hr_people') return '#ask-people-ops or people@acme.co';
  if (doc.category === 'security_it') return '#it-access-requests or #security-ops';
  if (doc.category === 'slack_threads') return doc.channelOrUrl || '#engineering';
  if (doc.category === 'product_wiki') return '#arch-review-board or #rfc-discussion';
  
  return '#eng-support or #general-help';
}
