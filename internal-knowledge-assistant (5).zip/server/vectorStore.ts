import { GoogleGenAI } from '@google/genai';
import { DocumentChunk, KnowledgeDocument, SearchResult, SourceCategory } from '../src/types.js';
import { INITIAL_COMPANY_DOCUMENTS } from './defaultDocs.js';

let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY') {
    try {
      geminiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (e) {
      console.warn('[VectorStore] Failed to initialize GoogleGenAI client for embeddings:', e);
    }
  }
  return geminiClient;
}

// In-memory document and chunk store with high-performance vector retrieval
class VectorStore {
  private documents: Map<string, KnowledgeDocument> = new Map();
  private chunks: DocumentChunk[] = [];
  private isInitialized = false;

  constructor() {
    // Pre-populate with initial company documents
    for (const doc of INITIAL_COMPANY_DOCUMENTS) {
      this.documents.set(doc.id, doc);
    }
  }

  public initialize(): void {
    if (this.isInitialized) return;
    console.log('[VectorStore] Initializing vector store with default documents...');
    this.reindexAll();
    this.isInitialized = true;
    console.log(`[VectorStore] Initialized with ${this.documents.size} documents and ${this.chunks.length} chunks.`);
  }

  public getDocuments(): KnowledgeDocument[] {
    return Array.from(this.documents.values()).map(doc => {
      const docChunks = this.chunks.filter(c => c.docId === doc.id);
      return {
        ...doc,
        chunkCount: docChunks.length,
      };
    });
  }

  public getDocumentById(id: string): KnowledgeDocument | undefined {
    return this.documents.get(id);
  }

  public getChunks(): DocumentChunk[] {
    return this.chunks;
  }

  public addDocument(doc: Omit<KnowledgeDocument, 'chunkCount'>): KnowledgeDocument {
    this.documents.set(doc.id, doc);
    const newChunks = this.chunkDocument(doc);
    
    // Generate vector embeddings for new chunks
    this.embedChunks(newChunks);
    
    // Remove old chunks if editing
    this.chunks = this.chunks.filter(c => c.docId !== doc.id);
    this.chunks.push(...newChunks);

    return {
      ...doc,
      chunkCount: newChunks.length,
    };
  }

  public deleteDocument(id: string): boolean {
    const deleted = this.documents.delete(id);
    if (deleted) {
      this.chunks = this.chunks.filter(c => c.docId !== id);
    }
    return deleted;
  }

  public reindexAll(): void {
    const allChunks: DocumentChunk[] = [];
    for (const doc of this.documents.values()) {
      const docChunks = this.chunkDocument(doc);
      allChunks.push(...docChunks);
    }
    this.embedChunks(allChunks);
    this.chunks = allChunks;
  }

  /**
   * Split document into semantically meaningful chunks (preserving headers & context)
   */
  private chunkDocument(doc: KnowledgeDocument): DocumentChunk[] {
    const rawContent = doc.content.trim();
    // Split by major Markdown headers (## or #) or paragraph blocks
    const sections = rawContent.split(/\n(?=#{1,3}\s)/g).filter(s => s.trim().length > 0);
    const chunks: DocumentChunk[] = [];

    let chunkIdx = 0;

    for (const section of sections) {
      const cleanSection = section.trim();
      if (!cleanSection) continue;

      // If a section is very long (> 1200 characters), split by double newline paragraphs
      if (cleanSection.length > 1200) {
        const paragraphs = cleanSection.split(/\n\n+/);
        let currentSubChunk = '';

        for (const p of paragraphs) {
          if ((currentSubChunk + '\n\n' + p).length > 1000 && currentSubChunk.length > 0) {
            chunks.push(this.createChunkObject(doc, currentSubChunk, chunkIdx++));
            currentSubChunk = p;
          } else {
            currentSubChunk = currentSubChunk ? `${currentSubChunk}\n\n${p}` : p;
          }
        }
        if (currentSubChunk.trim().length > 0) {
          chunks.push(this.createChunkObject(doc, currentSubChunk, chunkIdx++));
        }
      } else {
        chunks.push(this.createChunkObject(doc, cleanSection, chunkIdx++));
      }
    }

    // Set totalChunks count accurately across all chunks of this doc
    return chunks.map(c => ({
      ...c,
      totalChunks: chunks.length,
    }));
  }

  private createChunkObject(doc: KnowledgeDocument, text: string, index: number): DocumentChunk {
    const enrichedText = `[Document: ${doc.title} | Category: ${doc.category} | Source: ${doc.sourceType} | Dept: ${doc.department}]\n${text.trim()}`;
    const tokenEstimate = Math.ceil(enrichedText.length / 4);
    return {
      id: `${doc.id}-chunk-${index + 1}`,
      docId: doc.id,
      docTitle: doc.title,
      category: doc.category,
      sourceType: doc.sourceType,
      department: doc.department,
      channelOrUrl: doc.channelOrUrl,
      chunkIndex: index + 1,
      totalChunks: 0, // filled later
      text: enrichedText,
      tokenCount: tokenEstimate,
    };
  }

  /**
   * Embed chunks using fast dense vector projection with sub-word n-grams and domain weights
   */
  private embedChunks(chunks: DocumentChunk[]): void {
    for (const c of chunks) {
      c.embedding = this.computeDenseEmbedding(c.text);
    }
  }

  /**
   * Compute vector embedding: deterministic 256-dim dense vector projection
   */
  public computeEmbedding(text: string): number[] {
    return this.computeDenseEmbedding(text);
  }

  /**
   * 256-dimensional dense semantic embedding with sub-word n-grams and domain weights
   */
  public computeDenseEmbedding(text: string): number[] {
    const dim = 256;
    const vec = new Array(dim).fill(0);
    const clean = text.toLowerCase();
    const words = clean.replace(/[^a-z0-9\s_#-]/g, ' ').split(/\s+/).filter(w => w.length > 1);

    // 1. Unigram & Bigram TF-IDF semantic projection
    for (let i = 0; i < words.length; i++) {
      const word = words[i];
      const posWeight = 1.0 / Math.sqrt(i + 1);
      
      // Token Hash
      let h1 = 0;
      for (let c = 0; c < word.length; c++) {
        h1 = ((h1 << 5) - h1 + word.charCodeAt(c)) | 0;
      }
      const idx1 = Math.abs(h1) % dim;
      vec[idx1] += (1.5 + posWeight);

      // Character 3-grams for subword morphological matching
      if (word.length >= 3) {
        for (let g = 0; g <= word.length - 3; g++) {
          const gram = word.slice(g, g + 3);
          let hg = 0;
          for (let gc = 0; gc < 3; gc++) {
            hg = ((hg << 5) - hg + gram.charCodeAt(gc)) | 0;
          }
          const idxG = Math.abs(hg) % dim;
          vec[idxG] += 0.4;
        }
      }

      // Bigram token association
      if (i < words.length - 1) {
        const bigram = `${word}_${words[i + 1]}`;
        let h2 = 0;
        for (let c = 0; c < bigram.length; c++) {
          h2 = ((h2 << 5) - h2 + bigram.charCodeAt(c)) | 0;
        }
        const idx2 = Math.abs(h2) % dim;
        vec[idx2] += 2.0;
      }
    }

    // 2. High-salience domain entity boost
    const domainEntities = [
      'docker', 'apple', 'silicon', 'm1', 'm2', 'arm64', 'doppler', 'teleport', 'tsh',
      'staging', 'postgres', 'database', 'seed', 'fidelity', '401k', 'match', 'vesting',
      'brex', 'stipend', 'pto', 'holiday', '1password', 'vault', 'aws', 'iam', 'okta',
      'kafka', 'rfc', 'cap', 'drp', 'sla', 'pr', 'github', 'jira', 'confluence', 'slack'
    ];

    for (const entity of domainEntities) {
      if (clean.includes(entity)) {
        let he = 0;
        for (let c = 0; c < entity.length; c++) {
          he = ((he << 5) - he + entity.charCodeAt(c)) | 0;
        }
        const idxE = Math.abs(he) % dim;
        vec[idxE] += 4.0;
      }
    }

    // Normalize vector
    return this.normalizeVector(vec);
  }

  private normalizeVector(vec: number[]): number[] {
    let sumSq = 0;
    for (const v of vec) sumSq += v * v;
    const magnitude = Math.sqrt(sumSq);
    if (magnitude === 0) return vec;
    return vec.map(v => v / magnitude);
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    if (!a || !b || a.length === 0 || b.length === 0) return 0;
    const minLen = Math.min(a.length, b.length);
    let dot = 0;
    for (let i = 0; i < minLen; i++) {
      dot += a[i] * b[i];
    }
    // True cosine similarity on unit vectors (clamp negative noise to 0)
    return Math.max(0, Math.min(1, dot));
  }

  /**
   * Search vector index using hybrid vector cosine + token BM25 ranking
   */
  public async search(
    query: string,
    topK: number = 4,
    categoryFilter?: SourceCategory | 'all'
  ): Promise<SearchResult[]> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    let candidateChunks = this.chunks;
    if (categoryFilter) {
      const normalizedFilter = categoryFilter.toLowerCase();
      if (normalizedFilter !== 'all') {
        candidateChunks = candidateChunks.filter(c => c.category.toLowerCase() === normalizedFilter);
      }
    }

    if (candidateChunks.length === 0) {
      return [];
    }

    const queryVec = this.computeEmbedding(query);
    const stopwords = new Set([
      'a', 'an', 'the', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 'be', 'been',
      'in', 'on', 'at', 'to', 'for', 'with', 'by', 'about', 'against', 'between',
      'into', 'through', 'during', 'before', 'after', 'above', 'below', 'from',
      'up', 'down', 'in', 'out', 'off', 'over', 'under', 'again', 'further',
      'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all',
      'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such',
      'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very',
      'can', 'will', 'just', 'don', 'should', 'now', 'what', 'which', 'who', 'whom',
      'this', 'that', 'these', 'those', 'am', 'it', 'its', 'do', 'does', 'did'
    ]);

    const rawTokens = query
      .toLowerCase()
      .replace(/[^a-z0-9\s_-]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 1);

    const meaningfulTokens = rawTokens.filter(w => !stopwords.has(w));
    const queryTokens = meaningfulTokens.length > 0 ? meaningfulTokens : rawTokens;

    const scored: SearchResult[] = [];

    for (const chunk of candidateChunks) {
      const chunkVec = chunk.embedding || this.computeDenseEmbedding(chunk.text);
      const vecScore = this.cosineSimilarity(queryVec, chunkVec);

      // Lexical & keyword density score
      const chunkTextLower = chunk.text.toLowerCase();
      const matchedKeywords: string[] = [];

      let keywordHits = 0;
      for (const token of queryTokens) {
        if (chunkTextLower.includes(token)) {
          matchedKeywords.push(token);
          // Check frequency
          const regex = new RegExp(`\\b${token}\\b`, 'gi');
          const matches = chunkTextLower.match(regex);
          const count = matches ? matches.length : 1;
          keywordHits += Math.min(count, 4);
        }
      }

      const totalTokens = Math.max(1, queryTokens.length);
      const kwScore = Math.min(1.0, (keywordHits / totalTokens) * 0.8 + (matchedKeywords.length / totalTokens) * 0.2);

      // Boost if title matches
      let titleBoost = 0;
      const titleLower = chunk.docTitle.toLowerCase();
      for (const token of queryTokens) {
        if (titleLower.includes(token)) {
          titleBoost += 0.15;
        }
      }

      // Hybrid ranker formula: require minimum lexical/semantic grounding
      let combinedScore = 0;
      if (matchedKeywords.length > 0 || vecScore > 0.65) {
        combinedScore = Math.min(1.0, (vecScore * 0.50) + (kwScore * 0.40) + Math.min(0.2, titleBoost));
      } else {
        combinedScore = vecScore * 0.35; // heavily dampen when no keyword overlap
      }

      scored.push({
        chunk,
        score: Math.round(combinedScore * 1000) / 1000,
        vectorScore: Math.round(vecScore * 1000) / 1000,
        keywordScore: Math.round(kwScore * 1000) / 1000,
        matchedKeywords: Array.from(new Set(matchedKeywords)),
      });
    }

    // Sort descending by score
    scored.sort((a, b) => b.score - a.score);

    return scored.slice(0, topK);
  }
}

export const vectorStore = new VectorStore();
