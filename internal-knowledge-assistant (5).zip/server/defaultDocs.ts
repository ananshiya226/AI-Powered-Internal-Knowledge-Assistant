// Note: All company names, employee names, credentials, policies, URLs, and internal documents used in this project are synthetic/demo data created for educational and portfolio purposes.
import { KnowledgeDocument } from '../src/types.js';

export const INITIAL_COMPANY_DOCUMENTS: KnowledgeDocument[] = [
  {
    id: 'doc-eng-001',
    title: 'Engineering Onboarding: Local Dev Environment & Microservices',
    category: 'engineering',
    sourceType: 'wiki',
    author: 'Elena Rostova (Staff Platform Eng)',
    lastUpdated: '2026-06-15',
    channelOrUrl: 'https://wiki.internal.acme.co/eng/local-dev-guide',
    department: 'Engineering',
    tags: ['docker', 'nodejs', 'go', 'local-setup', 'staging', 'git'],
    content: `
# Engineering Local Development & Tooling Guide

Welcome to the engineering team! This guide walks you through provisioning your local dev machine, accessing our Docker registry, running the microservice stack, and configuring local env keys.

## 1. Prerequisites & Toolchain Setup
- Install Homebrew (macOS) or setup Linux dev packages.
- Ensure Docker Desktop (or OrbStack) has at least 8GB RAM allocated in settings.
- Node.js version requirement: v20.x LTS. Use \`nvm install 20 && nvm use 20\`.
- Go version 1.22+ for our backend microservices (Auth Service, Billing Worker, Payment Streamer).
- AWS CLI v2: Install via brew: \`brew install awscli\`. Run \`aws-sso login --profile acme-dev\`.

## 2. Cloning Repositories & Monorepo Setup
Our core codebase is organized in our GitHub Enterprise organization at \`github.internal.acme.co/platform\`.
1. Core Web App: \`git clone git@github.internal.acme.co:platform/web-frontend.git\`
2. Backend API Gateway & Services: \`git clone git@github.internal.acme.co:platform/api-gateway.git\`
3. Shared Type Definitions: \`git clone git@github.internal.acme.co:platform/shared-proto.git\`

## 3. Local Secrets & Doppler Vault
NEVER commit raw .env secrets or AWS keys to Git.
We use Doppler for secret management.
1. Run \`brew install dopplerhq/cli/doppler\`
2. Authenticate: \`doppler login\` (use your Okta SSO work email).
3. In any service directory, run \`doppler setup --project api-gateway --config dev\`
4. Start your server with secrets injected: \`doppler run -- npm run dev\`.

## 4. Running the Local Stack
To start the database, Redis cache, and mock Kafka message broker:
\`\`\`bash
cd api-gateway
make docker-up
\`\`\`
This spawns:
- PostgreSQL on \`localhost:5432\` (User: \`acme_dev\`, Pass: \`<local-dev-password>\`, DB: \`acme_core\`)
- Redis cluster on \`localhost:6379\`
- LocalStack AWS emulator on \`localhost:4566\`

For assistance or architecture questions, ping #eng-onboarding or tag @platform-help in Slack.
`
  },
  {
    id: 'doc-eng-002',
    title: 'Git Workflow, CI/CD Pipeline & Staging Deployment RFC',
    category: 'engineering',
    sourceType: 'rfc',
    author: 'Marcus Chen (VP of Engineering)',
    lastUpdated: '2026-07-20',
    channelOrUrl: 'https://wiki.internal.acme.co/eng/ci-cd-rfc-042',
    department: 'Engineering',
    tags: ['git', 'ci-cd', 'github-actions', 'argocd', 'kubernetes', 'pr-review'],
    content: `
# Git Workflow, Pull Request Guidelines & CI/CD Deployment

## 1. Branch Naming Convention
Every branch created in our repositories must follow the standardized format:
- \`feat/PROJ-1234-short-description\` (Feature branches linked to Jira)
- \`fix/PROJ-5678-bug-fix-summary\` (Bug fixes)
- \`chore/update-dependencies-q3\` (Maintenance)
- \`hotfix/auth-token-patch\` (Direct urgent production patches)

## 2. Pull Request & Code Review SLA
- All PRs require at least 2 approving reviews before merge.
- One review must be from the designated CodeOwner for that service directory.
- Code review SLA: Engineers must review assigned peer PRs within 4 business hours.
- Automated checks: PR must pass ESLint, TypeScript typecheck, Go test coverage (>80%), and Snyk security audit.

## 3. CI/CD Staging & Preview Environments
- When you open a PR on \`web-frontend\` or \`api-gateway\`, GitHub Actions automatically provisions an ephemeral staging preview environment at \`https://pr-<PR_NUMBER>.staging.acme.co\`.
- Staging databases are sanitized clones generated daily at 02:00 UTC with all PII scrubbed.
- Merging to \`main\` triggers an automated rollout to the Staging Kubernetes cluster via ArgoCD.
- Production deploys occur Tuesdays and Thursdays at 10:00 AM PST following QA sign-off in Jira.

## 4. Rollback Procedure
If a regression occurs in production:
1. Trigger \`/deploy rollback api-gateway prod\` in Slack channel #deployments.
2. The ArgoCD pipeline will revert to the previous verified SHA within 90 seconds.
3. Post-mortem RFC is required within 48 hours for any P0/P1 incident.
`
  },
  {
    id: 'doc-hr-001',
    title: 'People Ops: 401(k) Retirement Match & Equity Vesting Policy',
    category: 'hr_people',
    sourceType: 'policy',
    author: 'Sarah Jenkins (Director of Total Rewards)',
    lastUpdated: '2026-05-10',
    channelOrUrl: 'https://notion.internal.acme.co/people/401k-benefits',
    department: 'People Operations',
    tags: ['401k', 'fidelity', 'retirement', 'equity', 'vesting', 'options'],
    content: `
# Total Rewards: 401(k) Matching and Equity Plan

## 1. 401(k) Retirement Plan Overview
Acme Corp partners with Fidelity Investments for our 401(k) retirement savings plan, offering both Pre-Tax Traditional and Roth 401(k) contribution options.

### Company Match Formula
- Acme provides a 100% dollar-for-dollar match on your first 4% of eligible salary, plus an additional 50% match on the next 2%.
- Maximum company match is 5.0% of your total base salary.
- Safe Harbor Vesting: All employer matching contributions vest IMMEDIATELY (100% vested from Day 1).
- Plan ID in Fidelity: Acme Corp Plan #89421.

### How to Enroll
1. Log in to Fidelity NetBenefits at \`netbenefits.fidelity.com\` using your SSN/Employee ID.
2. Navigate to "Contributions" > "Change Contribution Percentage".
3. New hires can enroll immediately; contributions begin on the first paycheck following enrollment.
4. Auto-enrollment default: If you do not make a selection within 30 days of hire, you are auto-enrolled at 4% Pre-Tax into a Target Date Retirement Fund.

## 2. Equity & Stock Options (Carta)
- Equity grants (RSUs or ISOs) are managed through Carta (\`carta.com\`).
- Vesting Schedule: Standard 4-year vesting schedule with a 1-year cliff (25% vests on your 1-year work anniversary, followed by monthly vesting for the remaining 36 months).
- For questions regarding exercise windows, 83(b) elections, or secondary liquidity, email equity@acme.co.
`
  },
  {
    id: 'doc-hr-002',
    title: 'Health, Dental, Vision Insurance & Annual L&D Stipend',
    category: 'hr_people',
    sourceType: 'policy',
    author: 'David Alvarez (Benefits Lead)',
    lastUpdated: '2026-06-01',
    channelOrUrl: 'https://notion.internal.acme.co/people/health-insurance-stipends',
    department: 'People Operations',
    tags: ['health-insurance', 'gusto', 'workday', 'stipend', 'education', 'wellness', 'pto'],
    content: `
# Health Benefits, Wellness & Learning Stipend Guidelines

## 1. Medical, Dental & Vision Coverage
- Benefit plans are administered through Gusto / Workday.
- Acme covers 90% of employee healthcare premiums and 75% for dependents across our Platinum PPO (Blue Shield) and High Deductible Health Plan (HDHP with HSA).
- HSA Contribution: Acme deposits $1,000 (Individual) or $2,000 (Family) annually into your HSA if enrolled in the HDHP plan.
- Open Enrollment occurs annually in November. New hires have a 30-day window from hire date to select their coverage.

## 2. Learning & Development (L&D) $1,500 Annual Stipend
Every full-time employee receives a $1,500 annual budget for professional development:
- Eligible expenses: Tech conferences, books, online courses (Coursera, Udemy, O'Reilly), professional certifications (AWS, PMP, CISA), and industry memberships.
- Reimbursement: Submit receipts via Brex Expense under category "L&D Stipend". Approval is automated for purchases under $500.

## 3. Home Office & Wellness Reimbursement
- Remote setup: One-time $750 home office equipment stipend upon onboarding (monitors, ergonomic chairs, desk accessories).
- Monthly Wellness Allowance: $100/month reimbursed through Brex for gym memberships, fitness subscriptions, mental health apps (Headspace, Calm), or ergonomic gear.

## 4. Flexible Time Off (FTO) & Holidays
- Unlimited Flexible Time Off for exempt employees (recommended minimum of 4 weeks per year).
- 12 paid company holidays + 2 floating cultural holidays.
- Sick Leave: Separate 10 dedicated paid sick days annually.
- Requesting Time Off: Submit your dates in BambooHR with at least 2 weeks notice for planned vacations longer than 3 consecutive days.
`
  },
  {
    id: 'doc-sec-001',
    title: 'Security, Okta SSO, 1Password & AWS IAM Access Guidelines',
    category: 'security_it',
    sourceType: 'wiki',
    author: 'Priya Sharma (Head of Information Security)',
    lastUpdated: '2026-08-01',
    channelOrUrl: 'https://wiki.internal.acme.co/security/iam-onboarding',
    department: 'Information Security',
    tags: ['security', 'okta', 'mfa', '1password', 'aws-iam', 'vpn', 'teleport'],
    content: `
# Security & Access Protocols

## 1. Identity & Single Sign-On (Okta)
- Okta is our central Identity Provider (\`acme.okta.com\`).
- Mandatory MFA: YubiKey hardware token or Okta Verify with Number Matching push notifications. SMS verification is strictly deprecated.
- Password requirements: Minimum 16 characters managed via 1Password.

## 2. 1Password Enterprise Vault
- All team members receive a 1Password Enterprise account.
- Accept the invite sent to your work email on Day 1.
- Shared vaults: Each squad has a team vault (e.g. \`[Team] Platform-Shared\`, \`[Team] Growth-Shared\`).
- Storing customer credentials or production keys in plaintext notes is a Tier 1 security violation.

## 3. Infrastructure Access via Teleport & Bastion
We do not use standard SSH keys or open VPN ports for production server access.
- Access is gated by Teleport Bastion: \`https://teleport.internal.acme.co\`.
- CLI Setup:
  1. \`brew install teleport\`
  2. \`tsh login --proxy=teleport.internal.acme.co:443 --auth=okta\`
  3. View available clusters: \`tsh ls\`
  4. Connect to staging cluster: \`tsh ssh staging-k8s-node-01\`

## 4. Requesting Temporary Elevated AWS Permissions
To request staging or production read/write access:
1. Go to Slack channel \`#it-access-requests\`.
2. Type command \`/access request aws-prod-readonly --duration 4h --reason "Investigating payment gateway bug PROJ-992"\`.
3. Your squad manager or on-call Security lead will approve the request within the Slack interactive thread.
`
  },
  {
    id: 'doc-slack-001',
    title: 'Slack Thread Archive: Docker Silicon Build Errors on Mac M1/M2/M3',
    category: 'slack_threads',
    sourceType: 'slack',
    author: 'Slack Archive Bot (Imported from #eng-support)',
    lastUpdated: '2026-07-28',
    channelOrUrl: '#eng-support (Thread #t-8849201)',
    department: 'Engineering',
    tags: ['slack', 'docker', 'apple-silicon', 'm1', 'm2', 'colima', 'buildx'],
    content: `
# Slack Thread: #eng-support — Resolving Apple Silicon Docker Architecture Errors

**Jordan Reed (New Hire Eng)**:
Hey team! I just cloned \`api-gateway\` and ran \`make docker-up\`. I'm on an M3 MacBook Pro and getting this error:
\`exec /bin/sh: exec format error\` when building the \`payment-streamer\` image. Anyone know the fix?

**Elena Rostova (Staff Platform Eng)**:
Hey Jordan! Classic Apple Silicon issue. The base image was compiled for linux/amd64. You need to enable Docker Buildx emulation or set the platform flag in your compose file.

Here is the exact fix:
1. In your \`docker-compose.local.yml\`, add:
\`\`\`yaml
platform: linux/amd64
\`\`\`
under the \`payment-streamer\` and \`auth-service\` service definitions.

2. Alternatively, run docker with the default platform env var:
\`\`\`bash
export DOCKER_DEFAULT_PLATFORM=linux/amd64
make docker-up
\`\`\`

3. In Docker Desktop Settings: Go to **Settings > General** and ensure "Use Rosetta for x86/amd64 emulation on Apple Silicon" is CHECKED. It speeds up the build by 5x!

**Jordan Reed**:
Adding \`export DOCKER_DEFAULT_PLATFORM=linux/amd64\` and checking the Rosetta box fixed it immediately! Thanks Elena! 🚀
`
  },
  {
    id: 'doc-slack-002',
    title: 'Slack Thread Archive: How to Sanitize & Download Staging DB Dumps',
    category: 'slack_threads',
    sourceType: 'slack',
    author: 'Slack Archive Bot (Imported from #ask-it)',
    lastUpdated: '2026-08-05',
    channelOrUrl: '#ask-it (Thread #t-9120443)',
    department: 'IT & Data Platform',
    tags: ['slack', 'database', 'staging', 'postgresql', 'sanitized-data', 'seed'],
    content: `
# Slack Thread: #ask-it — How to refresh local database with sanitized staging data

**Chloe Wang (Full-stack Eng)**:
Hi! I need realistic test data for the new subscription billing dashboard. How can I seed my local Postgres with test accounts?

**Devon Price (Data Platform Lead)**:
Do NOT dump production! We have an automated nightly pipeline that generates a fully anonymized seed file with fake emails, credit cards, and randomized user IDs.

Here is the command to pull the latest sanitized snapshot:
\`\`\`bash
# 1. Ensure you are logged into AWS SSO
aws-sso login --profile acme-dev

# 2. Run the seed pull script from the repo root
./scripts/db-sync-seed.sh --target=local

# 3. If you only need mock fixtures for unit tests:
npm run seed:fixtures
\`\`\`

The script will download \`s3://acme-dev-fixtures/latest-sanitized-dump.sql.gz\` and import it into your local container running on port 5432. All user passwords are automatically reset to \`<sanitized-local-password>\`.
`
  },
  {
    id: 'doc-slack-003',
    title: 'Slack Thread Archive: Expense Reporting Deadlines & Brex Card Activation',
    category: 'slack_threads',
    sourceType: 'slack',
    author: 'Slack Archive Bot (Imported from #finance-help)',
    lastUpdated: '2026-08-12',
    channelOrUrl: '#finance-help (Thread #t-9310842)',
    department: 'Finance',
    tags: ['slack', 'brex', 'expenses', 'reimbursement', 'receipts', 'finance'],
    content: `
# Slack Thread: #finance-help — Expense policies and Brex card activation

**Amir Patel (Product Manager)**:
Quick question for Finance: What is the deadline to submit monthly SaaS software expenses and home internet reimbursements?

**Lydia Vance (Corporate Controller)**:
Hey Amir!
1. Expense Submission Deadline: The 5th business day of each following calendar month (e.g. August expenses must be submitted by September 8th).
2. Receipt Policy: Any transaction over $25 requires an attached receipt or invoice PDF in Brex.
3. Home Internet: We reimburse up to $75/month for home broadband. Label the category as "Remote Work > Internet".
4. To activate your physical Brex card: Download the Brex mobile app, enter the 4-digit code on the back, and set your PIN. Virtual cards are available immediately in Apple Pay / Google Wallet.
`
  },
  {
    id: 'doc-prod-001',
    title: 'Product & Architecture: RFC-042 Microservice Communication & Kafka Event Bus',
    category: 'product_wiki',
    sourceType: 'rfc',
    author: 'Alex Thorne (Principal Architect)',
    lastUpdated: '2026-06-25',
    channelOrUrl: 'https://wiki.internal.acme.co/arch/rfc-042-event-bus',
    department: 'Product & Engineering',
    tags: ['architecture', 'microservices', 'kafka', 'event-driven', 'grpc', 'apis'],
    content: `
# RFC-042: Event-Driven Inter-Service Communication Standard

## 1. Overview & System Boundaries
Acme's backend consists of four primary domains:
1. **Auth & Identity Service (Go / gRPC)**: Handles SSO tokens, session management, and RBAC permissions.
2. **User & Workspace Service (Node.js / Express)**: User profiles, organizations, and team memberships.
3. **Billing & Subscriptions Service (Go / Stripe integration)**: Invoicing, usage metering, and payment capture.
4. **Notification Engine (Python / Celery)**: Email, Slack webhook dispatch, and SMS delivery.

## 2. Synchronous vs Asynchronous Protocols
- Synchronous RPC: For internal high-throughput service-to-service queries, use gRPC over HTTP/2 with protobuf schemas defined in \`shared-proto\`.
- External Ingress: All external client requests pass through Kong API Gateway on \`api.acme.co\`.
- Asynchronous Events: All state mutations (e.g. \`user.created\`, \`subscription.upgraded\`, \`invoice.paid\`) MUST publish an event to our Kafka cluster (\`kafka-prod.internal.acme.co:9092\`).

## 3. Event Schema Evolution Rules
- All event payloads must adhere to Avro schemas registered in Schema Registry.
- Breaking changes (removing fields or renaming required keys) are strictly forbidden; fields must be deprecated for at least 2 quarters with non-breaking optional fields added.
`
  },
  {
    id: 'doc-glo-001',
    title: 'Company Glossary: Internal Acronyms, Jargon & Team Slang',
    category: 'glossary',
    sourceType: 'wiki',
    author: 'Internal Knowledge Guild',
    lastUpdated: '2026-08-01',
    channelOrUrl: 'https://wiki.internal.acme.co/glossary/internal-acronyms',
    department: 'Company-Wide',
    tags: ['glossary', 'acronyms', 'jargon', 'slang', 'definitions', 'onboarding'],
    content: `
# Acme Internal Acronyms & Terminology Glossary

Here is a guide to help you decode common terms used in meetings, PRs, and Slack:

- **CAP**: Customer Advisory Panel (our quarterly focus group of top enterprise accounts).
- **Dogfooding Cluster**: Our internal pre-release environment where all Acme employees test the latest features 2 weeks before public release.
- **DRP**: Disaster Recovery Protocol (our SOC-2 compliant failover playbook).
- **EPD**: Engineering, Product, and Design tri-pillar organization.
- **FTO**: Flexible Time Off (our unlimited vacation policy).
- **GTM**: Go-To-Market team (encompasses Sales, Solutions Engineering, Marketing, and Customer Success).
- **P0 / P1 / P2**: Incident severity scale. P0 = Complete outage affecting customers (15m response SLA); P1 = Major feature broken with no workaround (1h SLA); P2 = Minor degradation (4h SLA).
- **RFC**: Request For Comments (our architectural decision proposal template).
- **Safe Harbor 401(k)**: Acme's retirement match structure where company contributions vest immediately 100%.
- **Squad**: Small cross-functional team consisting of 1 PM, 1 Designer, 4-6 Engineers, and 1 QA/Data analyst.
- **WBR / QBR**: Weekly Business Review / Quarterly Business Review.
`
  }
];
